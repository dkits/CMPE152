
#include "wci/intermediate/TypeSpec.h"
using namespace wci::intermediate;


// Generated from SimpleC.g4 by ANTLR 4.7.1


#include "SimpleCVisitor.h"

#include "SimpleCParser.h"


using namespace antlrcpp;
using namespace antlr4;

SimpleCParser::SimpleCParser(TokenStream *input) : Parser(input) {
  _interpreter = new atn::ParserATNSimulator(this, _atn, _decisionToDFA, _sharedContextCache);
}

SimpleCParser::~SimpleCParser() {
  delete _interpreter;
}

std::string SimpleCParser::getGrammarFileName() const {
  return "SimpleC.g4";
}

const std::vector<std::string>& SimpleCParser::getRuleNames() const {
  return _ruleNames;
}

dfa::Vocabulary& SimpleCParser::getVocabulary() const {
  return _vocabulary;
}


//----------------- ProgContext ------------------------------------------------------------------

SimpleCParser::ProgContext::ProgContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

SimpleCParser::HeaderContext* SimpleCParser::ProgContext::header() {
  return getRuleContext<SimpleCParser::HeaderContext>(0);
}

SimpleCParser::BlockContext* SimpleCParser::ProgContext::block() {
  return getRuleContext<SimpleCParser::BlockContext>(0);
}


size_t SimpleCParser::ProgContext::getRuleIndex() const {
  return SimpleCParser::RuleProg;
}

antlrcpp::Any SimpleCParser::ProgContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitProg(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::ProgContext* SimpleCParser::prog() {
  ProgContext *_localctx = _tracker.createInstance<ProgContext>(_ctx, getState());
  enterRule(_localctx, 0, SimpleCParser::RuleProg);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(42);
    header();
    setState(43);
    match(SimpleCParser::T__0);
    setState(44);
    block();
    setState(45);
    match(SimpleCParser::T__1);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- HeaderContext ------------------------------------------------------------------

SimpleCParser::HeaderContext::HeaderContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* SimpleCParser::HeaderContext::MAIN() {
  return getToken(SimpleCParser::MAIN, 0);
}


size_t SimpleCParser::HeaderContext::getRuleIndex() const {
  return SimpleCParser::RuleHeader;
}

antlrcpp::Any SimpleCParser::HeaderContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitHeader(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::HeaderContext* SimpleCParser::header() {
  HeaderContext *_localctx = _tracker.createInstance<HeaderContext>(_ctx, getState());
  enterRule(_localctx, 2, SimpleCParser::RuleHeader);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(47);
    match(SimpleCParser::MAIN);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- BlockContext ------------------------------------------------------------------

SimpleCParser::BlockContext::BlockContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<SimpleCParser::StatContext *> SimpleCParser::BlockContext::stat() {
  return getRuleContexts<SimpleCParser::StatContext>();
}

SimpleCParser::StatContext* SimpleCParser::BlockContext::stat(size_t i) {
  return getRuleContext<SimpleCParser::StatContext>(i);
}


size_t SimpleCParser::BlockContext::getRuleIndex() const {
  return SimpleCParser::RuleBlock;
}

antlrcpp::Any SimpleCParser::BlockContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitBlock(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::BlockContext* SimpleCParser::block() {
  BlockContext *_localctx = _tracker.createInstance<BlockContext>(_ctx, getState());
  enterRule(_localctx, 4, SimpleCParser::RuleBlock);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(50); 
    _errHandler->sync(this);
    _la = _input->LA(1);
    do {
      setState(49);
      stat();
      setState(52); 
      _errHandler->sync(this);
      _la = _input->LA(1);
    } while ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << SimpleCParser::T__0)
      | (1ULL << SimpleCParser::T__4)
      | (1ULL << SimpleCParser::T__6)
      | (1ULL << SimpleCParser::T__7)
      | (1ULL << SimpleCParser::T__8)
      | (1ULL << SimpleCParser::T__10)
      | (1ULL << SimpleCParser::ID))) != 0));
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- StatContext ------------------------------------------------------------------

SimpleCParser::StatContext::StatContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t SimpleCParser::StatContext::getRuleIndex() const {
  return SimpleCParser::RuleStat;
}

void SimpleCParser::StatContext::copyFrom(StatContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- StatCallContext ------------------------------------------------------------------

SimpleCParser::Func_callContext* SimpleCParser::StatCallContext::func_call() {
  return getRuleContext<SimpleCParser::Func_callContext>(0);
}

SimpleCParser::StatCallContext::StatCallContext(StatContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::StatCallContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitStatCall(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StatIDContext ------------------------------------------------------------------

SimpleCParser::FuncIDContext* SimpleCParser::StatIDContext::funcID() {
  return getRuleContext<SimpleCParser::FuncIDContext>(0);
}

SimpleCParser::ExprContext* SimpleCParser::StatIDContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}

SimpleCParser::StatIDContext::StatIDContext(StatContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::StatIDContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitStatID(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StatWhileContext ------------------------------------------------------------------

SimpleCParser::While_statContext* SimpleCParser::StatWhileContext::while_stat() {
  return getRuleContext<SimpleCParser::While_statContext>(0);
}

SimpleCParser::StatWhileContext::StatWhileContext(StatContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::StatWhileContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitStatWhile(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StatRetContext ------------------------------------------------------------------

SimpleCParser::ExprContext* SimpleCParser::StatRetContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}

SimpleCParser::StatRetContext::StatRetContext(StatContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::StatRetContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitStatRet(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StatVarContext ------------------------------------------------------------------

SimpleCParser::Var_decContext* SimpleCParser::StatVarContext::var_dec() {
  return getRuleContext<SimpleCParser::Var_decContext>(0);
}

SimpleCParser::StatVarContext::StatVarContext(StatContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::StatVarContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitStatVar(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StatID_equalsContext ------------------------------------------------------------------

SimpleCParser::FuncIDContext* SimpleCParser::StatID_equalsContext::funcID() {
  return getRuleContext<SimpleCParser::FuncIDContext>(0);
}

SimpleCParser::ExprContext* SimpleCParser::StatID_equalsContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}

std::vector<SimpleCParser::StatContext *> SimpleCParser::StatID_equalsContext::stat() {
  return getRuleContexts<SimpleCParser::StatContext>();
}

SimpleCParser::StatContext* SimpleCParser::StatID_equalsContext::stat(size_t i) {
  return getRuleContext<SimpleCParser::StatContext>(i);
}

SimpleCParser::StatID_equalsContext::StatID_equalsContext(StatContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::StatID_equalsContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitStatID_equals(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StatIfContext ------------------------------------------------------------------

SimpleCParser::If_statContext* SimpleCParser::StatIfContext::if_stat() {
  return getRuleContext<SimpleCParser::If_statContext>(0);
}

SimpleCParser::StatIfContext::StatIfContext(StatContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::StatIfContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitStatIf(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StatFuncContext ------------------------------------------------------------------

SimpleCParser::FunctionContext* SimpleCParser::StatFuncContext::function() {
  return getRuleContext<SimpleCParser::FunctionContext>(0);
}

SimpleCParser::StatFuncContext::StatFuncContext(StatContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::StatFuncContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitStatFunc(this);
  else
    return visitor->visitChildren(this);
}
SimpleCParser::StatContext* SimpleCParser::stat() {
  StatContext *_localctx = _tracker.createInstance<StatContext>(_ctx, getState());
  enterRule(_localctx, 6, SimpleCParser::RuleStat);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(85);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 5, _ctx)) {
    case 1: {
      _localctx = dynamic_cast<StatContext *>(_tracker.createInstance<SimpleCParser::StatIDContext>(_localctx));
      enterOuterAlt(_localctx, 1);
      setState(54);
      funcID();
      setState(55);
      match(SimpleCParser::T__2);
      setState(56);
      expr(0);
      setState(57);
      match(SimpleCParser::T__3);
      break;
    }

    case 2: {
      _localctx = dynamic_cast<StatContext *>(_tracker.createInstance<SimpleCParser::StatID_equalsContext>(_localctx));
      enterOuterAlt(_localctx, 2);
      setState(59);
      match(SimpleCParser::T__0);
      setState(65);
      _errHandler->sync(this);

      switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 1, _ctx)) {
      case 1: {
        setState(60);
        funcID();
        setState(61);
        match(SimpleCParser::T__2);
        setState(62);
        expr(0);
        setState(63);
        match(SimpleCParser::T__3);
        break;
      }

      }
      setState(72);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if ((((_la & ~ 0x3fULL) == 0) &&
        ((1ULL << _la) & ((1ULL << SimpleCParser::T__0)
        | (1ULL << SimpleCParser::T__4)
        | (1ULL << SimpleCParser::T__6)
        | (1ULL << SimpleCParser::T__7)
        | (1ULL << SimpleCParser::T__8)
        | (1ULL << SimpleCParser::T__10)
        | (1ULL << SimpleCParser::ID))) != 0)) {
        setState(68); 
        _errHandler->sync(this);
        _la = _input->LA(1);
        do {
          setState(67);
          stat();
          setState(70); 
          _errHandler->sync(this);
          _la = _input->LA(1);
        } while ((((_la & ~ 0x3fULL) == 0) &&
          ((1ULL << _la) & ((1ULL << SimpleCParser::T__0)
          | (1ULL << SimpleCParser::T__4)
          | (1ULL << SimpleCParser::T__6)
          | (1ULL << SimpleCParser::T__7)
          | (1ULL << SimpleCParser::T__8)
          | (1ULL << SimpleCParser::T__10)
          | (1ULL << SimpleCParser::ID))) != 0));
      }
      setState(74);
      match(SimpleCParser::T__1);
      break;
    }

    case 3: {
      _localctx = dynamic_cast<StatContext *>(_tracker.createInstance<SimpleCParser::StatVarContext>(_localctx));
      enterOuterAlt(_localctx, 3);
      setState(75);
      var_dec();
      break;
    }

    case 4: {
      _localctx = dynamic_cast<StatContext *>(_tracker.createInstance<SimpleCParser::StatIfContext>(_localctx));
      enterOuterAlt(_localctx, 4);
      setState(76);
      if_stat();
      break;
    }

    case 5: {
      _localctx = dynamic_cast<StatContext *>(_tracker.createInstance<SimpleCParser::StatWhileContext>(_localctx));
      enterOuterAlt(_localctx, 5);
      setState(77);
      while_stat();
      break;
    }

    case 6: {
      _localctx = dynamic_cast<StatContext *>(_tracker.createInstance<SimpleCParser::StatFuncContext>(_localctx));
      enterOuterAlt(_localctx, 6);
      setState(78);
      function();
      break;
    }

    case 7: {
      _localctx = dynamic_cast<StatContext *>(_tracker.createInstance<SimpleCParser::StatCallContext>(_localctx));
      enterOuterAlt(_localctx, 7);
      setState(79);
      func_call();
      break;
    }

    case 8: {
      _localctx = dynamic_cast<StatContext *>(_tracker.createInstance<SimpleCParser::StatRetContext>(_localctx));
      enterOuterAlt(_localctx, 8);
      setState(80);
      match(SimpleCParser::T__4);
      setState(82);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if ((((_la & ~ 0x3fULL) == 0) &&
        ((1ULL << _la) & ((1ULL << SimpleCParser::T__11)
        | (1ULL << SimpleCParser::T__12)
        | (1ULL << SimpleCParser::ID)
        | (1ULL << SimpleCParser::INT)
        | (1ULL << SimpleCParser::BOOL))) != 0)) {
        setState(81);
        expr(0);
      }
      setState(84);
      match(SimpleCParser::T__3);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Var_decContext ------------------------------------------------------------------

SimpleCParser::Var_decContext::Var_decContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

SimpleCParser::VarOPContext* SimpleCParser::Var_decContext::varOP() {
  return getRuleContext<SimpleCParser::VarOPContext>(0);
}

SimpleCParser::VarListContext* SimpleCParser::Var_decContext::varList() {
  return getRuleContext<SimpleCParser::VarListContext>(0);
}

SimpleCParser::ExprContext* SimpleCParser::Var_decContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}


size_t SimpleCParser::Var_decContext::getRuleIndex() const {
  return SimpleCParser::RuleVar_dec;
}

antlrcpp::Any SimpleCParser::Var_decContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitVar_dec(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::Var_decContext* SimpleCParser::var_dec() {
  Var_decContext *_localctx = _tracker.createInstance<Var_decContext>(_ctx, getState());
  enterRule(_localctx, 8, SimpleCParser::RuleVar_dec);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(87);
    varOP();
    setState(88);
    varList();
    setState(91);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == SimpleCParser::T__2) {
      setState(89);
      match(SimpleCParser::T__2);
      setState(90);
      expr(0);
    }
    setState(93);
    match(SimpleCParser::T__3);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- VarListContext ------------------------------------------------------------------

SimpleCParser::VarListContext::VarListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<SimpleCParser::VarIDContext *> SimpleCParser::VarListContext::varID() {
  return getRuleContexts<SimpleCParser::VarIDContext>();
}

SimpleCParser::VarIDContext* SimpleCParser::VarListContext::varID(size_t i) {
  return getRuleContext<SimpleCParser::VarIDContext>(i);
}


size_t SimpleCParser::VarListContext::getRuleIndex() const {
  return SimpleCParser::RuleVarList;
}

antlrcpp::Any SimpleCParser::VarListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitVarList(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::VarListContext* SimpleCParser::varList() {
  VarListContext *_localctx = _tracker.createInstance<VarListContext>(_ctx, getState());
  enterRule(_localctx, 10, SimpleCParser::RuleVarList);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(95);
    varID();
    setState(100);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == SimpleCParser::T__5) {
      setState(96);
      match(SimpleCParser::T__5);
      setState(97);
      varID();
      setState(102);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- VarIDContext ------------------------------------------------------------------

SimpleCParser::VarIDContext::VarIDContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* SimpleCParser::VarIDContext::ID() {
  return getToken(SimpleCParser::ID, 0);
}


size_t SimpleCParser::VarIDContext::getRuleIndex() const {
  return SimpleCParser::RuleVarID;
}

antlrcpp::Any SimpleCParser::VarIDContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitVarID(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::VarIDContext* SimpleCParser::varID() {
  VarIDContext *_localctx = _tracker.createInstance<VarIDContext>(_ctx, getState());
  enterRule(_localctx, 12, SimpleCParser::RuleVarID);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(103);
    match(SimpleCParser::ID);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- VarOPContext ------------------------------------------------------------------

SimpleCParser::VarOPContext::VarOPContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t SimpleCParser::VarOPContext::getRuleIndex() const {
  return SimpleCParser::RuleVarOP;
}

antlrcpp::Any SimpleCParser::VarOPContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitVarOP(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::VarOPContext* SimpleCParser::varOP() {
  VarOPContext *_localctx = _tracker.createInstance<VarOPContext>(_ctx, getState());
  enterRule(_localctx, 14, SimpleCParser::RuleVarOP);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(105);
    _la = _input->LA(1);
    if (!(_la == SimpleCParser::T__6

    || _la == SimpleCParser::T__7)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- If_statContext ------------------------------------------------------------------

SimpleCParser::If_statContext::If_statContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

SimpleCParser::ExprContext* SimpleCParser::If_statContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}

std::vector<SimpleCParser::StatContext *> SimpleCParser::If_statContext::stat() {
  return getRuleContexts<SimpleCParser::StatContext>();
}

SimpleCParser::StatContext* SimpleCParser::If_statContext::stat(size_t i) {
  return getRuleContext<SimpleCParser::StatContext>(i);
}


size_t SimpleCParser::If_statContext::getRuleIndex() const {
  return SimpleCParser::RuleIf_stat;
}

antlrcpp::Any SimpleCParser::If_statContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitIf_stat(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::If_statContext* SimpleCParser::if_stat() {
  If_statContext *_localctx = _tracker.createInstance<If_statContext>(_ctx, getState());
  enterRule(_localctx, 16, SimpleCParser::RuleIf_stat);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(107);
    match(SimpleCParser::T__8);
    setState(108);
    expr(0);
    setState(109);
    stat();
    setState(112);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 8, _ctx)) {
    case 1: {
      setState(110);
      match(SimpleCParser::T__9);
      setState(111);
      stat();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- While_statContext ------------------------------------------------------------------

SimpleCParser::While_statContext::While_statContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

SimpleCParser::ExprContext* SimpleCParser::While_statContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}

SimpleCParser::StatContext* SimpleCParser::While_statContext::stat() {
  return getRuleContext<SimpleCParser::StatContext>(0);
}


size_t SimpleCParser::While_statContext::getRuleIndex() const {
  return SimpleCParser::RuleWhile_stat;
}

antlrcpp::Any SimpleCParser::While_statContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitWhile_stat(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::While_statContext* SimpleCParser::while_stat() {
  While_statContext *_localctx = _tracker.createInstance<While_statContext>(_ctx, getState());
  enterRule(_localctx, 18, SimpleCParser::RuleWhile_stat);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(114);
    match(SimpleCParser::T__10);
    setState(115);
    expr(0);
    setState(116);
    stat();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- FunctionContext ------------------------------------------------------------------

SimpleCParser::FunctionContext::FunctionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

SimpleCParser::VarOPContext* SimpleCParser::FunctionContext::varOP() {
  return getRuleContext<SimpleCParser::VarOPContext>(0);
}

tree::TerminalNode* SimpleCParser::FunctionContext::ID() {
  return getToken(SimpleCParser::ID, 0);
}

SimpleCParser::StatContext* SimpleCParser::FunctionContext::stat() {
  return getRuleContext<SimpleCParser::StatContext>(0);
}

SimpleCParser::ExprContext* SimpleCParser::FunctionContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}


size_t SimpleCParser::FunctionContext::getRuleIndex() const {
  return SimpleCParser::RuleFunction;
}

antlrcpp::Any SimpleCParser::FunctionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitFunction(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::FunctionContext* SimpleCParser::function() {
  FunctionContext *_localctx = _tracker.createInstance<FunctionContext>(_ctx, getState());
  enterRule(_localctx, 20, SimpleCParser::RuleFunction);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(118);
    varOP();
    setState(119);
    match(SimpleCParser::ID);
    setState(121);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 9, _ctx)) {
    case 1: {
      setState(120);
      expr(0);
      break;
    }

    }
    setState(123);
    stat();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Func_callContext ------------------------------------------------------------------

SimpleCParser::Func_callContext::Func_callContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* SimpleCParser::Func_callContext::ID() {
  return getToken(SimpleCParser::ID, 0);
}

SimpleCParser::ExprContext* SimpleCParser::Func_callContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}


size_t SimpleCParser::Func_callContext::getRuleIndex() const {
  return SimpleCParser::RuleFunc_call;
}

antlrcpp::Any SimpleCParser::Func_callContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitFunc_call(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::Func_callContext* SimpleCParser::func_call() {
  Func_callContext *_localctx = _tracker.createInstance<Func_callContext>(_ctx, getState());
  enterRule(_localctx, 22, SimpleCParser::RuleFunc_call);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(125);
    match(SimpleCParser::ID);
    setState(126);
    expr(0);
    setState(127);
    match(SimpleCParser::T__3);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExprContext ------------------------------------------------------------------

SimpleCParser::ExprContext::ExprContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t SimpleCParser::ExprContext::getRuleIndex() const {
  return SimpleCParser::RuleExpr;
}

void SimpleCParser::ExprContext::copyFrom(ExprContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
  this->type = ctx->type;
}

//----------------- ExprMultDivContext ------------------------------------------------------------------

std::vector<SimpleCParser::ExprContext *> SimpleCParser::ExprMultDivContext::expr() {
  return getRuleContexts<SimpleCParser::ExprContext>();
}

SimpleCParser::ExprContext* SimpleCParser::ExprMultDivContext::expr(size_t i) {
  return getRuleContext<SimpleCParser::ExprContext>(i);
}

SimpleCParser::MulDivOpContext* SimpleCParser::ExprMultDivContext::mulDivOp() {
  return getRuleContext<SimpleCParser::MulDivOpContext>(0);
}

SimpleCParser::ExprMultDivContext::ExprMultDivContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::ExprMultDivContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitExprMultDiv(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ExprFuncIntContext ------------------------------------------------------------------

SimpleCParser::NumContext* SimpleCParser::ExprFuncIntContext::num() {
  return getRuleContext<SimpleCParser::NumContext>(0);
}

SimpleCParser::ExprContext* SimpleCParser::ExprFuncIntContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}

SimpleCParser::ExprFuncIntContext::ExprFuncIntContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::ExprFuncIntContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitExprFuncInt(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ExprCompContext ------------------------------------------------------------------

std::vector<SimpleCParser::ExprContext *> SimpleCParser::ExprCompContext::expr() {
  return getRuleContexts<SimpleCParser::ExprContext>();
}

SimpleCParser::ExprContext* SimpleCParser::ExprCompContext::expr(size_t i) {
  return getRuleContext<SimpleCParser::ExprContext>(i);
}

SimpleCParser::CompOPContext* SimpleCParser::ExprCompContext::compOP() {
  return getRuleContext<SimpleCParser::CompOPContext>(0);
}

SimpleCParser::ExprCompContext::ExprCompContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::ExprCompContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitExprComp(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ExprAddSubContext ------------------------------------------------------------------

std::vector<SimpleCParser::ExprContext *> SimpleCParser::ExprAddSubContext::expr() {
  return getRuleContexts<SimpleCParser::ExprContext>();
}

SimpleCParser::ExprContext* SimpleCParser::ExprAddSubContext::expr(size_t i) {
  return getRuleContext<SimpleCParser::ExprContext>(i);
}

SimpleCParser::AddSubOpContext* SimpleCParser::ExprAddSubContext::addSubOp() {
  return getRuleContext<SimpleCParser::AddSubOpContext>(0);
}

SimpleCParser::ExprAddSubContext::ExprAddSubContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::ExprAddSubContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitExprAddSub(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ExprParaContext ------------------------------------------------------------------

SimpleCParser::ExprContext* SimpleCParser::ExprParaContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}

SimpleCParser::ExprParaContext::ExprParaContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::ExprParaContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitExprPara(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ExprFuncIDContext ------------------------------------------------------------------

SimpleCParser::FuncIDContext* SimpleCParser::ExprFuncIDContext::funcID() {
  return getRuleContext<SimpleCParser::FuncIDContext>(0);
}

SimpleCParser::ExprContext* SimpleCParser::ExprFuncIDContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}

SimpleCParser::ExprFuncIDContext::ExprFuncIDContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::ExprFuncIDContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitExprFuncID(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ExprFuncBoolContext ------------------------------------------------------------------

SimpleCParser::BoolnContext* SimpleCParser::ExprFuncBoolContext::booln() {
  return getRuleContext<SimpleCParser::BoolnContext>(0);
}

SimpleCParser::ExprContext* SimpleCParser::ExprFuncBoolContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}

SimpleCParser::ExprFuncBoolContext::ExprFuncBoolContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::ExprFuncBoolContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitExprFuncBool(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::ExprContext* SimpleCParser::expr() {
   return expr(0);
}

SimpleCParser::ExprContext* SimpleCParser::expr(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  SimpleCParser::ExprContext *_localctx = _tracker.createInstance<ExprContext>(_ctx, parentState);
  SimpleCParser::ExprContext *previousContext = _localctx;
  size_t startState = 24;
  enterRecursionRule(_localctx, 24, SimpleCParser::RuleExpr, precedence);

    size_t _la = 0;

  auto onExit = finally([=] {
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(167);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 19, _ctx)) {
    case 1: {
      _localctx = _tracker.createInstance<ExprFuncIntContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;

      setState(131);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == SimpleCParser::T__11) {
        setState(130);
        match(SimpleCParser::T__11);
      }
      setState(133);
      num();
      setState(139);
      _errHandler->sync(this);

      switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 12, _ctx)) {
      case 1: {
        setState(134);
        match(SimpleCParser::T__5);
        setState(136);
        _errHandler->sync(this);

        switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 11, _ctx)) {
        case 1: {
          setState(135);
          match(SimpleCParser::T__11);
          break;
        }

        }
        setState(138);
        expr(0);
        break;
      }

      }
      break;
    }

    case 2: {
      _localctx = _tracker.createInstance<ExprFuncIDContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;
      setState(142);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == SimpleCParser::T__11) {
        setState(141);
        match(SimpleCParser::T__11);
      }
      setState(144);
      funcID();
      setState(150);
      _errHandler->sync(this);

      switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 15, _ctx)) {
      case 1: {
        setState(145);
        match(SimpleCParser::T__5);
        setState(147);
        _errHandler->sync(this);

        switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 14, _ctx)) {
        case 1: {
          setState(146);
          match(SimpleCParser::T__11);
          break;
        }

        }
        setState(149);
        expr(0);
        break;
      }

      }
      break;
    }

    case 3: {
      _localctx = _tracker.createInstance<ExprFuncBoolContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;
      setState(153);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == SimpleCParser::T__11) {
        setState(152);
        match(SimpleCParser::T__11);
      }
      setState(155);
      booln();
      setState(161);
      _errHandler->sync(this);

      switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 18, _ctx)) {
      case 1: {
        setState(156);
        match(SimpleCParser::T__5);
        setState(158);
        _errHandler->sync(this);

        switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 17, _ctx)) {
        case 1: {
          setState(157);
          match(SimpleCParser::T__11);
          break;
        }

        }
        setState(160);
        expr(0);
        break;
      }

      }
      break;
    }

    case 4: {
      _localctx = _tracker.createInstance<ExprParaContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;
      setState(163);
      match(SimpleCParser::T__12);
      setState(164);
      expr(0);
      setState(165);
      match(SimpleCParser::T__13);
      break;
    }

    }
    _ctx->stop = _input->LT(-1);
    setState(183);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 21, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        setState(181);
        _errHandler->sync(this);
        switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 20, _ctx)) {
        case 1: {
          auto newContext = _tracker.createInstance<ExprMultDivContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(169);

          if (!(precpred(_ctx, 7))) throw FailedPredicateException(this, "precpred(_ctx, 7)");
          setState(170);
          mulDivOp();
          setState(171);
          expr(8);
          break;
        }

        case 2: {
          auto newContext = _tracker.createInstance<ExprAddSubContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(173);

          if (!(precpred(_ctx, 6))) throw FailedPredicateException(this, "precpred(_ctx, 6)");
          setState(174);
          addSubOp();
          setState(175);
          expr(7);
          break;
        }

        case 3: {
          auto newContext = _tracker.createInstance<ExprCompContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(177);

          if (!(precpred(_ctx, 5))) throw FailedPredicateException(this, "precpred(_ctx, 5)");
          setState(178);
          compOP();
          setState(179);
          expr(6);
          break;
        }

        } 
      }
      setState(185);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 21, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

//----------------- PrintContext ------------------------------------------------------------------

SimpleCParser::PrintContext::PrintContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* SimpleCParser::PrintContext::PRINT() {
  return getToken(SimpleCParser::PRINT, 0);
}

SimpleCParser::StringContext* SimpleCParser::PrintContext::string() {
  return getRuleContext<SimpleCParser::StringContext>(0);
}


size_t SimpleCParser::PrintContext::getRuleIndex() const {
  return SimpleCParser::RulePrint;
}

antlrcpp::Any SimpleCParser::PrintContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitPrint(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::PrintContext* SimpleCParser::print() {
  PrintContext *_localctx = _tracker.createInstance<PrintContext>(_ctx, getState());
  enterRule(_localctx, 26, SimpleCParser::RulePrint);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(186);
    match(SimpleCParser::PRINT);
    setState(187);
    match(SimpleCParser::T__12);
    setState(188);
    string();
    setState(189);
    match(SimpleCParser::T__13);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- StringContext ------------------------------------------------------------------

SimpleCParser::StringContext::StringContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* SimpleCParser::StringContext::ID() {
  return getToken(SimpleCParser::ID, 0);
}


size_t SimpleCParser::StringContext::getRuleIndex() const {
  return SimpleCParser::RuleString;
}

antlrcpp::Any SimpleCParser::StringContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitString(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::StringContext* SimpleCParser::string() {
  StringContext *_localctx = _tracker.createInstance<StringContext>(_ctx, getState());
  enterRule(_localctx, 28, SimpleCParser::RuleString);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(191);
    match(SimpleCParser::ID);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- FuncIDContext ------------------------------------------------------------------

SimpleCParser::FuncIDContext::FuncIDContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* SimpleCParser::FuncIDContext::ID() {
  return getToken(SimpleCParser::ID, 0);
}


size_t SimpleCParser::FuncIDContext::getRuleIndex() const {
  return SimpleCParser::RuleFuncID;
}

antlrcpp::Any SimpleCParser::FuncIDContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitFuncID(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::FuncIDContext* SimpleCParser::funcID() {
  FuncIDContext *_localctx = _tracker.createInstance<FuncIDContext>(_ctx, getState());
  enterRule(_localctx, 30, SimpleCParser::RuleFuncID);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(193);
    match(SimpleCParser::ID);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- CompOPContext ------------------------------------------------------------------

SimpleCParser::CompOPContext::CompOPContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t SimpleCParser::CompOPContext::getRuleIndex() const {
  return SimpleCParser::RuleCompOP;
}

antlrcpp::Any SimpleCParser::CompOPContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitCompOP(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::CompOPContext* SimpleCParser::compOP() {
  CompOPContext *_localctx = _tracker.createInstance<CompOPContext>(_ctx, getState());
  enterRule(_localctx, 32, SimpleCParser::RuleCompOP);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(195);
    _la = _input->LA(1);
    if (!((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << SimpleCParser::T__14)
      | (1ULL << SimpleCParser::T__15)
      | (1ULL << SimpleCParser::T__16)
      | (1ULL << SimpleCParser::T__17)
      | (1ULL << SimpleCParser::T__18))) != 0))) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- MulDivOpContext ------------------------------------------------------------------

SimpleCParser::MulDivOpContext::MulDivOpContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t SimpleCParser::MulDivOpContext::getRuleIndex() const {
  return SimpleCParser::RuleMulDivOp;
}

antlrcpp::Any SimpleCParser::MulDivOpContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitMulDivOp(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::MulDivOpContext* SimpleCParser::mulDivOp() {
  MulDivOpContext *_localctx = _tracker.createInstance<MulDivOpContext>(_ctx, getState());
  enterRule(_localctx, 34, SimpleCParser::RuleMulDivOp);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(197);
    _la = _input->LA(1);
    if (!(_la == SimpleCParser::T__19

    || _la == SimpleCParser::T__20)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- AddSubOpContext ------------------------------------------------------------------

SimpleCParser::AddSubOpContext::AddSubOpContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t SimpleCParser::AddSubOpContext::getRuleIndex() const {
  return SimpleCParser::RuleAddSubOp;
}

antlrcpp::Any SimpleCParser::AddSubOpContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitAddSubOp(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::AddSubOpContext* SimpleCParser::addSubOp() {
  AddSubOpContext *_localctx = _tracker.createInstance<AddSubOpContext>(_ctx, getState());
  enterRule(_localctx, 36, SimpleCParser::RuleAddSubOp);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(199);
    _la = _input->LA(1);
    if (!(_la == SimpleCParser::T__21

    || _la == SimpleCParser::T__22)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- NumContext ------------------------------------------------------------------

SimpleCParser::NumContext::NumContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t SimpleCParser::NumContext::getRuleIndex() const {
  return SimpleCParser::RuleNum;
}

void SimpleCParser::NumContext::copyFrom(NumContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
  this->type = ctx->type;
}

//----------------- IntegerConstContext ------------------------------------------------------------------

tree::TerminalNode* SimpleCParser::IntegerConstContext::INT() {
  return getToken(SimpleCParser::INT, 0);
}

SimpleCParser::IntegerConstContext::IntegerConstContext(NumContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::IntegerConstContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitIntegerConst(this);
  else
    return visitor->visitChildren(this);
}
SimpleCParser::NumContext* SimpleCParser::num() {
  NumContext *_localctx = _tracker.createInstance<NumContext>(_ctx, getState());
  enterRule(_localctx, 38, SimpleCParser::RuleNum);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    _localctx = dynamic_cast<NumContext *>(_tracker.createInstance<SimpleCParser::IntegerConstContext>(_localctx));
    enterOuterAlt(_localctx, 1);
    setState(201);
    match(SimpleCParser::INT);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- BoolnContext ------------------------------------------------------------------

SimpleCParser::BoolnContext::BoolnContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t SimpleCParser::BoolnContext::getRuleIndex() const {
  return SimpleCParser::RuleBooln;
}

void SimpleCParser::BoolnContext::copyFrom(BoolnContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
  this->type = ctx->type;
}

//----------------- BoolConstContext ------------------------------------------------------------------

tree::TerminalNode* SimpleCParser::BoolConstContext::BOOL() {
  return getToken(SimpleCParser::BOOL, 0);
}

SimpleCParser::BoolConstContext::BoolConstContext(BoolnContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::BoolConstContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitBoolConst(this);
  else
    return visitor->visitChildren(this);
}
SimpleCParser::BoolnContext* SimpleCParser::booln() {
  BoolnContext *_localctx = _tracker.createInstance<BoolnContext>(_ctx, getState());
  enterRule(_localctx, 40, SimpleCParser::RuleBooln);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    _localctx = dynamic_cast<BoolnContext *>(_tracker.createInstance<SimpleCParser::BoolConstContext>(_localctx));
    enterOuterAlt(_localctx, 1);
    setState(203);
    match(SimpleCParser::BOOL);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

bool SimpleCParser::sempred(RuleContext *context, size_t ruleIndex, size_t predicateIndex) {
  switch (ruleIndex) {
    case 12: return exprSempred(dynamic_cast<ExprContext *>(context), predicateIndex);

  default:
    break;
  }
  return true;
}

bool SimpleCParser::exprSempred(ExprContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 0: return precpred(_ctx, 7);
    case 1: return precpred(_ctx, 6);
    case 2: return precpred(_ctx, 5);

  default:
    break;
  }
  return true;
}

// Static vars and initialization.
std::vector<dfa::DFA> SimpleCParser::_decisionToDFA;
atn::PredictionContextCache SimpleCParser::_sharedContextCache;

// We own the ATN which in turn owns the ATN states.
atn::ATN SimpleCParser::_atn;
std::vector<uint16_t> SimpleCParser::_serializedATN;

std::vector<std::string> SimpleCParser::_ruleNames = {
  "prog", "header", "block", "stat", "var_dec", "varList", "varID", "varOP", 
  "if_stat", "while_stat", "function", "func_call", "expr", "print", "string", 
  "funcID", "compOP", "mulDivOp", "addSubOp", "num", "booln"
};

std::vector<std::string> SimpleCParser::_literalNames = {
  "", "'{'", "'}'", "'='", "';'", "'return'", "','", "'int'", "'bool'", 
  "'if'", "'else'", "'while'", "'#'", "'('", "')'", "'=='", "'>='", "'<='", 
  "'>'", "'<'", "'*'", "'/'", "'+'", "'-'", "'main'", "'print'"
};

std::vector<std::string> SimpleCParser::_symbolicNames = {
  "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", 
  "", "", "", "", "", "", "MAIN", "PRINT", "ID", "INT", "BOOL", "WS"
};

dfa::Vocabulary SimpleCParser::_vocabulary(_literalNames, _symbolicNames);

std::vector<std::string> SimpleCParser::_tokenNames;

SimpleCParser::Initializer::Initializer() {
	for (size_t i = 0; i < _symbolicNames.size(); ++i) {
		std::string name = _vocabulary.getLiteralName(i);
		if (name.empty()) {
			name = _vocabulary.getSymbolicName(i);
		}

		if (name.empty()) {
			_tokenNames.push_back("<INVALID>");
		} else {
      _tokenNames.push_back(name);
    }
	}

  _serializedATN = {
    0x3, 0x608b, 0xa72a, 0x8133, 0xb9ed, 0x417c, 0x3be7, 0x7786, 0x5964, 
    0x3, 0x1f, 0xd0, 0x4, 0x2, 0x9, 0x2, 0x4, 0x3, 0x9, 0x3, 0x4, 0x4, 0x9, 
    0x4, 0x4, 0x5, 0x9, 0x5, 0x4, 0x6, 0x9, 0x6, 0x4, 0x7, 0x9, 0x7, 0x4, 
    0x8, 0x9, 0x8, 0x4, 0x9, 0x9, 0x9, 0x4, 0xa, 0x9, 0xa, 0x4, 0xb, 0x9, 
    0xb, 0x4, 0xc, 0x9, 0xc, 0x4, 0xd, 0x9, 0xd, 0x4, 0xe, 0x9, 0xe, 0x4, 
    0xf, 0x9, 0xf, 0x4, 0x10, 0x9, 0x10, 0x4, 0x11, 0x9, 0x11, 0x4, 0x12, 
    0x9, 0x12, 0x4, 0x13, 0x9, 0x13, 0x4, 0x14, 0x9, 0x14, 0x4, 0x15, 0x9, 
    0x15, 0x4, 0x16, 0x9, 0x16, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 
    0x3, 0x2, 0x3, 0x3, 0x3, 0x3, 0x3, 0x4, 0x6, 0x4, 0x35, 0xa, 0x4, 0xd, 
    0x4, 0xe, 0x4, 0x36, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 
    0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x5, 0x5, 
    0x44, 0xa, 0x5, 0x3, 0x5, 0x6, 0x5, 0x47, 0xa, 0x5, 0xd, 0x5, 0xe, 0x5, 
    0x48, 0x5, 0x5, 0x4b, 0xa, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 
    0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x5, 0x5, 0x55, 0xa, 0x5, 0x3, 
    0x5, 0x5, 0x5, 0x58, 0xa, 0x5, 0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 
    0x5, 0x6, 0x5e, 0xa, 0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 0x7, 0x3, 0x7, 0x3, 
    0x7, 0x7, 0x7, 0x65, 0xa, 0x7, 0xc, 0x7, 0xe, 0x7, 0x68, 0xb, 0x7, 0x3, 
    0x8, 0x3, 0x8, 0x3, 0x9, 0x3, 0x9, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 
    0xa, 0x3, 0xa, 0x5, 0xa, 0x73, 0xa, 0xa, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 
    0x3, 0xb, 0x3, 0xc, 0x3, 0xc, 0x3, 0xc, 0x5, 0xc, 0x7c, 0xa, 0xc, 0x3, 
    0xc, 0x3, 0xc, 0x3, 0xd, 0x3, 0xd, 0x3, 0xd, 0x3, 0xd, 0x3, 0xe, 0x3, 
    0xe, 0x5, 0xe, 0x86, 0xa, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x5, 0xe, 
    0x8b, 0xa, 0xe, 0x3, 0xe, 0x5, 0xe, 0x8e, 0xa, 0xe, 0x3, 0xe, 0x5, 0xe, 
    0x91, 0xa, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x5, 0xe, 0x96, 0xa, 0xe, 
    0x3, 0xe, 0x5, 0xe, 0x99, 0xa, 0xe, 0x3, 0xe, 0x5, 0xe, 0x9c, 0xa, 0xe, 
    0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x5, 0xe, 0xa1, 0xa, 0xe, 0x3, 0xe, 0x5, 
    0xe, 0xa4, 0xa, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x5, 0xe, 
    0xaa, 0xa, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 
    0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x7, 
    0xe, 0xb8, 0xa, 0xe, 0xc, 0xe, 0xe, 0xe, 0xbb, 0xb, 0xe, 0x3, 0xf, 0x3, 
    0xf, 0x3, 0xf, 0x3, 0xf, 0x3, 0xf, 0x3, 0x10, 0x3, 0x10, 0x3, 0x11, 
    0x3, 0x11, 0x3, 0x12, 0x3, 0x12, 0x3, 0x13, 0x3, 0x13, 0x3, 0x14, 0x3, 
    0x14, 0x3, 0x15, 0x3, 0x15, 0x3, 0x16, 0x3, 0x16, 0x3, 0x16, 0x2, 0x3, 
    0x1a, 0x17, 0x2, 0x4, 0x6, 0x8, 0xa, 0xc, 0xe, 0x10, 0x12, 0x14, 0x16, 
    0x18, 0x1a, 0x1c, 0x1e, 0x20, 0x22, 0x24, 0x26, 0x28, 0x2a, 0x2, 0x6, 
    0x3, 0x2, 0x9, 0xa, 0x3, 0x2, 0x11, 0x15, 0x3, 0x2, 0x16, 0x17, 0x3, 
    0x2, 0x18, 0x19, 0x2, 0xd9, 0x2, 0x2c, 0x3, 0x2, 0x2, 0x2, 0x4, 0x31, 
    0x3, 0x2, 0x2, 0x2, 0x6, 0x34, 0x3, 0x2, 0x2, 0x2, 0x8, 0x57, 0x3, 0x2, 
    0x2, 0x2, 0xa, 0x59, 0x3, 0x2, 0x2, 0x2, 0xc, 0x61, 0x3, 0x2, 0x2, 0x2, 
    0xe, 0x69, 0x3, 0x2, 0x2, 0x2, 0x10, 0x6b, 0x3, 0x2, 0x2, 0x2, 0x12, 
    0x6d, 0x3, 0x2, 0x2, 0x2, 0x14, 0x74, 0x3, 0x2, 0x2, 0x2, 0x16, 0x78, 
    0x3, 0x2, 0x2, 0x2, 0x18, 0x7f, 0x3, 0x2, 0x2, 0x2, 0x1a, 0xa9, 0x3, 
    0x2, 0x2, 0x2, 0x1c, 0xbc, 0x3, 0x2, 0x2, 0x2, 0x1e, 0xc1, 0x3, 0x2, 
    0x2, 0x2, 0x20, 0xc3, 0x3, 0x2, 0x2, 0x2, 0x22, 0xc5, 0x3, 0x2, 0x2, 
    0x2, 0x24, 0xc7, 0x3, 0x2, 0x2, 0x2, 0x26, 0xc9, 0x3, 0x2, 0x2, 0x2, 
    0x28, 0xcb, 0x3, 0x2, 0x2, 0x2, 0x2a, 0xcd, 0x3, 0x2, 0x2, 0x2, 0x2c, 
    0x2d, 0x5, 0x4, 0x3, 0x2, 0x2d, 0x2e, 0x7, 0x3, 0x2, 0x2, 0x2e, 0x2f, 
    0x5, 0x6, 0x4, 0x2, 0x2f, 0x30, 0x7, 0x4, 0x2, 0x2, 0x30, 0x3, 0x3, 
    0x2, 0x2, 0x2, 0x31, 0x32, 0x7, 0x1a, 0x2, 0x2, 0x32, 0x5, 0x3, 0x2, 
    0x2, 0x2, 0x33, 0x35, 0x5, 0x8, 0x5, 0x2, 0x34, 0x33, 0x3, 0x2, 0x2, 
    0x2, 0x35, 0x36, 0x3, 0x2, 0x2, 0x2, 0x36, 0x34, 0x3, 0x2, 0x2, 0x2, 
    0x36, 0x37, 0x3, 0x2, 0x2, 0x2, 0x37, 0x7, 0x3, 0x2, 0x2, 0x2, 0x38, 
    0x39, 0x5, 0x20, 0x11, 0x2, 0x39, 0x3a, 0x7, 0x5, 0x2, 0x2, 0x3a, 0x3b, 
    0x5, 0x1a, 0xe, 0x2, 0x3b, 0x3c, 0x7, 0x6, 0x2, 0x2, 0x3c, 0x58, 0x3, 
    0x2, 0x2, 0x2, 0x3d, 0x43, 0x7, 0x3, 0x2, 0x2, 0x3e, 0x3f, 0x5, 0x20, 
    0x11, 0x2, 0x3f, 0x40, 0x7, 0x5, 0x2, 0x2, 0x40, 0x41, 0x5, 0x1a, 0xe, 
    0x2, 0x41, 0x42, 0x7, 0x6, 0x2, 0x2, 0x42, 0x44, 0x3, 0x2, 0x2, 0x2, 
    0x43, 0x3e, 0x3, 0x2, 0x2, 0x2, 0x43, 0x44, 0x3, 0x2, 0x2, 0x2, 0x44, 
    0x4a, 0x3, 0x2, 0x2, 0x2, 0x45, 0x47, 0x5, 0x8, 0x5, 0x2, 0x46, 0x45, 
    0x3, 0x2, 0x2, 0x2, 0x47, 0x48, 0x3, 0x2, 0x2, 0x2, 0x48, 0x46, 0x3, 
    0x2, 0x2, 0x2, 0x48, 0x49, 0x3, 0x2, 0x2, 0x2, 0x49, 0x4b, 0x3, 0x2, 
    0x2, 0x2, 0x4a, 0x46, 0x3, 0x2, 0x2, 0x2, 0x4a, 0x4b, 0x3, 0x2, 0x2, 
    0x2, 0x4b, 0x4c, 0x3, 0x2, 0x2, 0x2, 0x4c, 0x58, 0x7, 0x4, 0x2, 0x2, 
    0x4d, 0x58, 0x5, 0xa, 0x6, 0x2, 0x4e, 0x58, 0x5, 0x12, 0xa, 0x2, 0x4f, 
    0x58, 0x5, 0x14, 0xb, 0x2, 0x50, 0x58, 0x5, 0x16, 0xc, 0x2, 0x51, 0x58, 
    0x5, 0x18, 0xd, 0x2, 0x52, 0x54, 0x7, 0x7, 0x2, 0x2, 0x53, 0x55, 0x5, 
    0x1a, 0xe, 0x2, 0x54, 0x53, 0x3, 0x2, 0x2, 0x2, 0x54, 0x55, 0x3, 0x2, 
    0x2, 0x2, 0x55, 0x56, 0x3, 0x2, 0x2, 0x2, 0x56, 0x58, 0x7, 0x6, 0x2, 
    0x2, 0x57, 0x38, 0x3, 0x2, 0x2, 0x2, 0x57, 0x3d, 0x3, 0x2, 0x2, 0x2, 
    0x57, 0x4d, 0x3, 0x2, 0x2, 0x2, 0x57, 0x4e, 0x3, 0x2, 0x2, 0x2, 0x57, 
    0x4f, 0x3, 0x2, 0x2, 0x2, 0x57, 0x50, 0x3, 0x2, 0x2, 0x2, 0x57, 0x51, 
    0x3, 0x2, 0x2, 0x2, 0x57, 0x52, 0x3, 0x2, 0x2, 0x2, 0x58, 0x9, 0x3, 
    0x2, 0x2, 0x2, 0x59, 0x5a, 0x5, 0x10, 0x9, 0x2, 0x5a, 0x5d, 0x5, 0xc, 
    0x7, 0x2, 0x5b, 0x5c, 0x7, 0x5, 0x2, 0x2, 0x5c, 0x5e, 0x5, 0x1a, 0xe, 
    0x2, 0x5d, 0x5b, 0x3, 0x2, 0x2, 0x2, 0x5d, 0x5e, 0x3, 0x2, 0x2, 0x2, 
    0x5e, 0x5f, 0x3, 0x2, 0x2, 0x2, 0x5f, 0x60, 0x7, 0x6, 0x2, 0x2, 0x60, 
    0xb, 0x3, 0x2, 0x2, 0x2, 0x61, 0x66, 0x5, 0xe, 0x8, 0x2, 0x62, 0x63, 
    0x7, 0x8, 0x2, 0x2, 0x63, 0x65, 0x5, 0xe, 0x8, 0x2, 0x64, 0x62, 0x3, 
    0x2, 0x2, 0x2, 0x65, 0x68, 0x3, 0x2, 0x2, 0x2, 0x66, 0x64, 0x3, 0x2, 
    0x2, 0x2, 0x66, 0x67, 0x3, 0x2, 0x2, 0x2, 0x67, 0xd, 0x3, 0x2, 0x2, 
    0x2, 0x68, 0x66, 0x3, 0x2, 0x2, 0x2, 0x69, 0x6a, 0x7, 0x1c, 0x2, 0x2, 
    0x6a, 0xf, 0x3, 0x2, 0x2, 0x2, 0x6b, 0x6c, 0x9, 0x2, 0x2, 0x2, 0x6c, 
    0x11, 0x3, 0x2, 0x2, 0x2, 0x6d, 0x6e, 0x7, 0xb, 0x2, 0x2, 0x6e, 0x6f, 
    0x5, 0x1a, 0xe, 0x2, 0x6f, 0x72, 0x5, 0x8, 0x5, 0x2, 0x70, 0x71, 0x7, 
    0xc, 0x2, 0x2, 0x71, 0x73, 0x5, 0x8, 0x5, 0x2, 0x72, 0x70, 0x3, 0x2, 
    0x2, 0x2, 0x72, 0x73, 0x3, 0x2, 0x2, 0x2, 0x73, 0x13, 0x3, 0x2, 0x2, 
    0x2, 0x74, 0x75, 0x7, 0xd, 0x2, 0x2, 0x75, 0x76, 0x5, 0x1a, 0xe, 0x2, 
    0x76, 0x77, 0x5, 0x8, 0x5, 0x2, 0x77, 0x15, 0x3, 0x2, 0x2, 0x2, 0x78, 
    0x79, 0x5, 0x10, 0x9, 0x2, 0x79, 0x7b, 0x7, 0x1c, 0x2, 0x2, 0x7a, 0x7c, 
    0x5, 0x1a, 0xe, 0x2, 0x7b, 0x7a, 0x3, 0x2, 0x2, 0x2, 0x7b, 0x7c, 0x3, 
    0x2, 0x2, 0x2, 0x7c, 0x7d, 0x3, 0x2, 0x2, 0x2, 0x7d, 0x7e, 0x5, 0x8, 
    0x5, 0x2, 0x7e, 0x17, 0x3, 0x2, 0x2, 0x2, 0x7f, 0x80, 0x7, 0x1c, 0x2, 
    0x2, 0x80, 0x81, 0x5, 0x1a, 0xe, 0x2, 0x81, 0x82, 0x7, 0x6, 0x2, 0x2, 
    0x82, 0x19, 0x3, 0x2, 0x2, 0x2, 0x83, 0x85, 0x8, 0xe, 0x1, 0x2, 0x84, 
    0x86, 0x7, 0xe, 0x2, 0x2, 0x85, 0x84, 0x3, 0x2, 0x2, 0x2, 0x85, 0x86, 
    0x3, 0x2, 0x2, 0x2, 0x86, 0x87, 0x3, 0x2, 0x2, 0x2, 0x87, 0x8d, 0x5, 
    0x28, 0x15, 0x2, 0x88, 0x8a, 0x7, 0x8, 0x2, 0x2, 0x89, 0x8b, 0x7, 0xe, 
    0x2, 0x2, 0x8a, 0x89, 0x3, 0x2, 0x2, 0x2, 0x8a, 0x8b, 0x3, 0x2, 0x2, 
    0x2, 0x8b, 0x8c, 0x3, 0x2, 0x2, 0x2, 0x8c, 0x8e, 0x5, 0x1a, 0xe, 0x2, 
    0x8d, 0x88, 0x3, 0x2, 0x2, 0x2, 0x8d, 0x8e, 0x3, 0x2, 0x2, 0x2, 0x8e, 
    0xaa, 0x3, 0x2, 0x2, 0x2, 0x8f, 0x91, 0x7, 0xe, 0x2, 0x2, 0x90, 0x8f, 
    0x3, 0x2, 0x2, 0x2, 0x90, 0x91, 0x3, 0x2, 0x2, 0x2, 0x91, 0x92, 0x3, 
    0x2, 0x2, 0x2, 0x92, 0x98, 0x5, 0x20, 0x11, 0x2, 0x93, 0x95, 0x7, 0x8, 
    0x2, 0x2, 0x94, 0x96, 0x7, 0xe, 0x2, 0x2, 0x95, 0x94, 0x3, 0x2, 0x2, 
    0x2, 0x95, 0x96, 0x3, 0x2, 0x2, 0x2, 0x96, 0x97, 0x3, 0x2, 0x2, 0x2, 
    0x97, 0x99, 0x5, 0x1a, 0xe, 0x2, 0x98, 0x93, 0x3, 0x2, 0x2, 0x2, 0x98, 
    0x99, 0x3, 0x2, 0x2, 0x2, 0x99, 0xaa, 0x3, 0x2, 0x2, 0x2, 0x9a, 0x9c, 
    0x7, 0xe, 0x2, 0x2, 0x9b, 0x9a, 0x3, 0x2, 0x2, 0x2, 0x9b, 0x9c, 0x3, 
    0x2, 0x2, 0x2, 0x9c, 0x9d, 0x3, 0x2, 0x2, 0x2, 0x9d, 0xa3, 0x5, 0x2a, 
    0x16, 0x2, 0x9e, 0xa0, 0x7, 0x8, 0x2, 0x2, 0x9f, 0xa1, 0x7, 0xe, 0x2, 
    0x2, 0xa0, 0x9f, 0x3, 0x2, 0x2, 0x2, 0xa0, 0xa1, 0x3, 0x2, 0x2, 0x2, 
    0xa1, 0xa2, 0x3, 0x2, 0x2, 0x2, 0xa2, 0xa4, 0x5, 0x1a, 0xe, 0x2, 0xa3, 
    0x9e, 0x3, 0x2, 0x2, 0x2, 0xa3, 0xa4, 0x3, 0x2, 0x2, 0x2, 0xa4, 0xaa, 
    0x3, 0x2, 0x2, 0x2, 0xa5, 0xa6, 0x7, 0xf, 0x2, 0x2, 0xa6, 0xa7, 0x5, 
    0x1a, 0xe, 0x2, 0xa7, 0xa8, 0x7, 0x10, 0x2, 0x2, 0xa8, 0xaa, 0x3, 0x2, 
    0x2, 0x2, 0xa9, 0x83, 0x3, 0x2, 0x2, 0x2, 0xa9, 0x90, 0x3, 0x2, 0x2, 
    0x2, 0xa9, 0x9b, 0x3, 0x2, 0x2, 0x2, 0xa9, 0xa5, 0x3, 0x2, 0x2, 0x2, 
    0xaa, 0xb9, 0x3, 0x2, 0x2, 0x2, 0xab, 0xac, 0xc, 0x9, 0x2, 0x2, 0xac, 
    0xad, 0x5, 0x24, 0x13, 0x2, 0xad, 0xae, 0x5, 0x1a, 0xe, 0xa, 0xae, 0xb8, 
    0x3, 0x2, 0x2, 0x2, 0xaf, 0xb0, 0xc, 0x8, 0x2, 0x2, 0xb0, 0xb1, 0x5, 
    0x26, 0x14, 0x2, 0xb1, 0xb2, 0x5, 0x1a, 0xe, 0x9, 0xb2, 0xb8, 0x3, 0x2, 
    0x2, 0x2, 0xb3, 0xb4, 0xc, 0x7, 0x2, 0x2, 0xb4, 0xb5, 0x5, 0x22, 0x12, 
    0x2, 0xb5, 0xb6, 0x5, 0x1a, 0xe, 0x8, 0xb6, 0xb8, 0x3, 0x2, 0x2, 0x2, 
    0xb7, 0xab, 0x3, 0x2, 0x2, 0x2, 0xb7, 0xaf, 0x3, 0x2, 0x2, 0x2, 0xb7, 
    0xb3, 0x3, 0x2, 0x2, 0x2, 0xb8, 0xbb, 0x3, 0x2, 0x2, 0x2, 0xb9, 0xb7, 
    0x3, 0x2, 0x2, 0x2, 0xb9, 0xba, 0x3, 0x2, 0x2, 0x2, 0xba, 0x1b, 0x3, 
    0x2, 0x2, 0x2, 0xbb, 0xb9, 0x3, 0x2, 0x2, 0x2, 0xbc, 0xbd, 0x7, 0x1b, 
    0x2, 0x2, 0xbd, 0xbe, 0x7, 0xf, 0x2, 0x2, 0xbe, 0xbf, 0x5, 0x1e, 0x10, 
    0x2, 0xbf, 0xc0, 0x7, 0x10, 0x2, 0x2, 0xc0, 0x1d, 0x3, 0x2, 0x2, 0x2, 
    0xc1, 0xc2, 0x7, 0x1c, 0x2, 0x2, 0xc2, 0x1f, 0x3, 0x2, 0x2, 0x2, 0xc3, 
    0xc4, 0x7, 0x1c, 0x2, 0x2, 0xc4, 0x21, 0x3, 0x2, 0x2, 0x2, 0xc5, 0xc6, 
    0x9, 0x3, 0x2, 0x2, 0xc6, 0x23, 0x3, 0x2, 0x2, 0x2, 0xc7, 0xc8, 0x9, 
    0x4, 0x2, 0x2, 0xc8, 0x25, 0x3, 0x2, 0x2, 0x2, 0xc9, 0xca, 0x9, 0x5, 
    0x2, 0x2, 0xca, 0x27, 0x3, 0x2, 0x2, 0x2, 0xcb, 0xcc, 0x7, 0x1d, 0x2, 
    0x2, 0xcc, 0x29, 0x3, 0x2, 0x2, 0x2, 0xcd, 0xce, 0x7, 0x1e, 0x2, 0x2, 
    0xce, 0x2b, 0x3, 0x2, 0x2, 0x2, 0x18, 0x36, 0x43, 0x48, 0x4a, 0x54, 
    0x57, 0x5d, 0x66, 0x72, 0x7b, 0x85, 0x8a, 0x8d, 0x90, 0x95, 0x98, 0x9b, 
    0xa0, 0xa3, 0xa9, 0xb7, 0xb9, 
  };

  atn::ATNDeserializer deserializer;
  _atn = deserializer.deserialize(_serializedATN);

  size_t count = _atn.getNumberOfDecisions();
  _decisionToDFA.reserve(count);
  for (size_t i = 0; i < count; i++) { 
    _decisionToDFA.emplace_back(_atn.getDecisionState(i), i);
  }
}

SimpleCParser::Initializer SimpleCParser::_init;
