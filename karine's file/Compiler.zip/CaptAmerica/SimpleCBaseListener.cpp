
#include "wci/intermediate/TypeSpec.h"
using namespace wci::intermediate;


// Generated from SimpleC.g4 by ANTLR 4.7.1


#include "SimpleCBaseListener.h"


