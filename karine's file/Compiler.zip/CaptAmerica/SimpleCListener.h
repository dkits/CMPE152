
#include "wci/intermediate/TypeSpec.h"
using namespace wci::intermediate;


// Generated from SimpleC.g4 by ANTLR 4.7.1

#pragma once


#include "antlr4-runtime.h"
#include "SimpleCParser.h"


/**
 * This interface defines an abstract listener for a parse tree produced by SimpleCParser.
 */
class  SimpleCListener : public antlr4::tree::ParseTreeListener {
public:

  virtual void enterProg(SimpleCParser::ProgContext *ctx) = 0;
  virtual void exitProg(SimpleCParser::ProgContext *ctx) = 0;

  virtual void enterHeader(SimpleCParser::HeaderContext *ctx) = 0;
  virtual void exitHeader(SimpleCParser::HeaderContext *ctx) = 0;

  virtual void enterBlock(SimpleCParser::BlockContext *ctx) = 0;
  virtual void exitBlock(SimpleCParser::BlockContext *ctx) = 0;

  virtual void enterStatID(SimpleCParser::StatIDContext *ctx) = 0;
  virtual void exitStatID(SimpleCParser::StatIDContext *ctx) = 0;

  virtual void enterStatID_equals(SimpleCParser::StatID_equalsContext *ctx) = 0;
  virtual void exitStatID_equals(SimpleCParser::StatID_equalsContext *ctx) = 0;

  virtual void enterStatVar(SimpleCParser::StatVarContext *ctx) = 0;
  virtual void exitStatVar(SimpleCParser::StatVarContext *ctx) = 0;

  virtual void enterStatIf(SimpleCParser::StatIfContext *ctx) = 0;
  virtual void exitStatIf(SimpleCParser::StatIfContext *ctx) = 0;

  virtual void enterStatWhile(SimpleCParser::StatWhileContext *ctx) = 0;
  virtual void exitStatWhile(SimpleCParser::StatWhileContext *ctx) = 0;

  virtual void enterStatFunc(SimpleCParser::StatFuncContext *ctx) = 0;
  virtual void exitStatFunc(SimpleCParser::StatFuncContext *ctx) = 0;

  virtual void enterStatCall(SimpleCParser::StatCallContext *ctx) = 0;
  virtual void exitStatCall(SimpleCParser::StatCallContext *ctx) = 0;

  virtual void enterStatRet(SimpleCParser::StatRetContext *ctx) = 0;
  virtual void exitStatRet(SimpleCParser::StatRetContext *ctx) = 0;

  virtual void enterVar_dec(SimpleCParser::Var_decContext *ctx) = 0;
  virtual void exitVar_dec(SimpleCParser::Var_decContext *ctx) = 0;

  virtual void enterVarList(SimpleCParser::VarListContext *ctx) = 0;
  virtual void exitVarList(SimpleCParser::VarListContext *ctx) = 0;

  virtual void enterVarID(SimpleCParser::VarIDContext *ctx) = 0;
  virtual void exitVarID(SimpleCParser::VarIDContext *ctx) = 0;

  virtual void enterVarOP(SimpleCParser::VarOPContext *ctx) = 0;
  virtual void exitVarOP(SimpleCParser::VarOPContext *ctx) = 0;

  virtual void enterIf_stat(SimpleCParser::If_statContext *ctx) = 0;
  virtual void exitIf_stat(SimpleCParser::If_statContext *ctx) = 0;

  virtual void enterWhile_stat(SimpleCParser::While_statContext *ctx) = 0;
  virtual void exitWhile_stat(SimpleCParser::While_statContext *ctx) = 0;

  virtual void enterFunction(SimpleCParser::FunctionContext *ctx) = 0;
  virtual void exitFunction(SimpleCParser::FunctionContext *ctx) = 0;

  virtual void enterFunc_call(SimpleCParser::Func_callContext *ctx) = 0;
  virtual void exitFunc_call(SimpleCParser::Func_callContext *ctx) = 0;

  virtual void enterExprMultDiv(SimpleCParser::ExprMultDivContext *ctx) = 0;
  virtual void exitExprMultDiv(SimpleCParser::ExprMultDivContext *ctx) = 0;

  virtual void enterExprFuncInt(SimpleCParser::ExprFuncIntContext *ctx) = 0;
  virtual void exitExprFuncInt(SimpleCParser::ExprFuncIntContext *ctx) = 0;

  virtual void enterExprComp(SimpleCParser::ExprCompContext *ctx) = 0;
  virtual void exitExprComp(SimpleCParser::ExprCompContext *ctx) = 0;

  virtual void enterExprAddSub(SimpleCParser::ExprAddSubContext *ctx) = 0;
  virtual void exitExprAddSub(SimpleCParser::ExprAddSubContext *ctx) = 0;

  virtual void enterExprPara(SimpleCParser::ExprParaContext *ctx) = 0;
  virtual void exitExprPara(SimpleCParser::ExprParaContext *ctx) = 0;

  virtual void enterExprFuncID(SimpleCParser::ExprFuncIDContext *ctx) = 0;
  virtual void exitExprFuncID(SimpleCParser::ExprFuncIDContext *ctx) = 0;

  virtual void enterExprFuncBool(SimpleCParser::ExprFuncBoolContext *ctx) = 0;
  virtual void exitExprFuncBool(SimpleCParser::ExprFuncBoolContext *ctx) = 0;

  virtual void enterPrint(SimpleCParser::PrintContext *ctx) = 0;
  virtual void exitPrint(SimpleCParser::PrintContext *ctx) = 0;

  virtual void enterString(SimpleCParser::StringContext *ctx) = 0;
  virtual void exitString(SimpleCParser::StringContext *ctx) = 0;

  virtual void enterFuncID(SimpleCParser::FuncIDContext *ctx) = 0;
  virtual void exitFuncID(SimpleCParser::FuncIDContext *ctx) = 0;

  virtual void enterCompOP(SimpleCParser::CompOPContext *ctx) = 0;
  virtual void exitCompOP(SimpleCParser::CompOPContext *ctx) = 0;

  virtual void enterMulDivOp(SimpleCParser::MulDivOpContext *ctx) = 0;
  virtual void exitMulDivOp(SimpleCParser::MulDivOpContext *ctx) = 0;

  virtual void enterAddSubOp(SimpleCParser::AddSubOpContext *ctx) = 0;
  virtual void exitAddSubOp(SimpleCParser::AddSubOpContext *ctx) = 0;

  virtual void enterIntegerConst(SimpleCParser::IntegerConstContext *ctx) = 0;
  virtual void exitIntegerConst(SimpleCParser::IntegerConstContext *ctx) = 0;

  virtual void enterBoolConst(SimpleCParser::BoolConstContext *ctx) = 0;
  virtual void exitBoolConst(SimpleCParser::BoolConstContext *ctx) = 0;


};

