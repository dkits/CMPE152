
#include "wci/intermediate/TypeSpec.h"
using namespace wci::intermediate;


// Generated from SimpleC.g4 by ANTLR 4.7.1

#pragma once


#include "antlr4-runtime.h"
#include "SimpleCListener.h"


/**
 * This class provides an empty implementation of SimpleCListener,
 * which can be extended to create a listener which only needs to handle a subset
 * of the available methods.
 */
class  SimpleCBaseListener : public SimpleCListener {
public:

  virtual void enterProg(SimpleCParser::ProgContext * /*ctx*/) override { }
  virtual void exitProg(SimpleCParser::ProgContext * /*ctx*/) override { }

  virtual void enterHeader(SimpleCParser::HeaderContext * /*ctx*/) override { }
  virtual void exitHeader(SimpleCParser::HeaderContext * /*ctx*/) override { }

  virtual void enterBlock(SimpleCParser::BlockContext * /*ctx*/) override { }
  virtual void exitBlock(SimpleCParser::BlockContext * /*ctx*/) override { }

  virtual void enterDecl(SimpleCParser::DeclContext * /*ctx*/) override { }
  virtual void exitDecl(SimpleCParser::DeclContext * /*ctx*/) override { }

  virtual void enterStatassign(SimpleCParser::StatassignContext * /*ctx*/) override { }
  virtual void exitStatassign(SimpleCParser::StatassignContext * /*ctx*/) override { }

  virtual void enterStatIf(SimpleCParser::StatIfContext * /*ctx*/) override { }
  virtual void exitStatIf(SimpleCParser::StatIfContext * /*ctx*/) override { }

  virtual void enterStatWhile(SimpleCParser::StatWhileContext * /*ctx*/) override { }
  virtual void exitStatWhile(SimpleCParser::StatWhileContext * /*ctx*/) override { }

  virtual void enterStatFunc(SimpleCParser::StatFuncContext * /*ctx*/) override { }
  virtual void exitStatFunc(SimpleCParser::StatFuncContext * /*ctx*/) override { }

  virtual void enterStatPrint(SimpleCParser::StatPrintContext * /*ctx*/) override { }
  virtual void exitStatPrint(SimpleCParser::StatPrintContext * /*ctx*/) override { }

  virtual void enterStatCall(SimpleCParser::StatCallContext * /*ctx*/) override { }
  virtual void exitStatCall(SimpleCParser::StatCallContext * /*ctx*/) override { }

  virtual void enterStatRet(SimpleCParser::StatRetContext * /*ctx*/) override { }
  virtual void exitStatRet(SimpleCParser::StatRetContext * /*ctx*/) override { }

  virtual void enterVar_dec(SimpleCParser::Var_decContext * /*ctx*/) override { }
  virtual void exitVar_dec(SimpleCParser::Var_decContext * /*ctx*/) override { }

  virtual void enterVarList(SimpleCParser::VarListContext * /*ctx*/) override { }
  virtual void exitVarList(SimpleCParser::VarListContext * /*ctx*/) override { }

  virtual void enterVarID(SimpleCParser::VarIDContext * /*ctx*/) override { }
  virtual void exitVarID(SimpleCParser::VarIDContext * /*ctx*/) override { }

  virtual void enterVarOP(SimpleCParser::VarOPContext * /*ctx*/) override { }
  virtual void exitVarOP(SimpleCParser::VarOPContext * /*ctx*/) override { }

  virtual void enterAssignment_stat(SimpleCParser::Assignment_statContext * /*ctx*/) override { }
  virtual void exitAssignment_stat(SimpleCParser::Assignment_statContext * /*ctx*/) override { }

  virtual void enterPrint(SimpleCParser::PrintContext * /*ctx*/) override { }
  virtual void exitPrint(SimpleCParser::PrintContext * /*ctx*/) override { }

  virtual void enterIf_stat(SimpleCParser::If_statContext * /*ctx*/) override { }
  virtual void exitIf_stat(SimpleCParser::If_statContext * /*ctx*/) override { }

  virtual void enterWhile_stat(SimpleCParser::While_statContext * /*ctx*/) override { }
  virtual void exitWhile_stat(SimpleCParser::While_statContext * /*ctx*/) override { }

  virtual void enterFunction(SimpleCParser::FunctionContext * /*ctx*/) override { }
  virtual void exitFunction(SimpleCParser::FunctionContext * /*ctx*/) override { }

  virtual void enterFunc_call(SimpleCParser::Func_callContext * /*ctx*/) override { }
  virtual void exitFunc_call(SimpleCParser::Func_callContext * /*ctx*/) override { }

  virtual void enterExprMultDiv(SimpleCParser::ExprMultDivContext * /*ctx*/) override { }
  virtual void exitExprMultDiv(SimpleCParser::ExprMultDivContext * /*ctx*/) override { }

  virtual void enterExprFuncInt(SimpleCParser::ExprFuncIntContext * /*ctx*/) override { }
  virtual void exitExprFuncInt(SimpleCParser::ExprFuncIntContext * /*ctx*/) override { }

  virtual void enterExprComp(SimpleCParser::ExprCompContext * /*ctx*/) override { }
  virtual void exitExprComp(SimpleCParser::ExprCompContext * /*ctx*/) override { }

  virtual void enterExprAddSub(SimpleCParser::ExprAddSubContext * /*ctx*/) override { }
  virtual void exitExprAddSub(SimpleCParser::ExprAddSubContext * /*ctx*/) override { }

  virtual void enterExprPara(SimpleCParser::ExprParaContext * /*ctx*/) override { }
  virtual void exitExprPara(SimpleCParser::ExprParaContext * /*ctx*/) override { }

  virtual void enterExprFuncID(SimpleCParser::ExprFuncIDContext * /*ctx*/) override { }
  virtual void exitExprFuncID(SimpleCParser::ExprFuncIDContext * /*ctx*/) override { }

  virtual void enterExprFuncBool(SimpleCParser::ExprFuncBoolContext * /*ctx*/) override { }
  virtual void exitExprFuncBool(SimpleCParser::ExprFuncBoolContext * /*ctx*/) override { }

  virtual void enterString(SimpleCParser::StringContext * /*ctx*/) override { }
  virtual void exitString(SimpleCParser::StringContext * /*ctx*/) override { }

  virtual void enterFuncID(SimpleCParser::FuncIDContext * /*ctx*/) override { }
  virtual void exitFuncID(SimpleCParser::FuncIDContext * /*ctx*/) override { }

  virtual void enterCompOP(SimpleCParser::CompOPContext * /*ctx*/) override { }
  virtual void exitCompOP(SimpleCParser::CompOPContext * /*ctx*/) override { }

  virtual void enterMulDivOp(SimpleCParser::MulDivOpContext * /*ctx*/) override { }
  virtual void exitMulDivOp(SimpleCParser::MulDivOpContext * /*ctx*/) override { }

  virtual void enterAddSubOp(SimpleCParser::AddSubOpContext * /*ctx*/) override { }
  virtual void exitAddSubOp(SimpleCParser::AddSubOpContext * /*ctx*/) override { }

  virtual void enterIntegerConst(SimpleCParser::IntegerConstContext * /*ctx*/) override { }
  virtual void exitIntegerConst(SimpleCParser::IntegerConstContext * /*ctx*/) override { }

  virtual void enterBoolConst(SimpleCParser::BoolConstContext * /*ctx*/) override { }
  virtual void exitBoolConst(SimpleCParser::BoolConstContext * /*ctx*/) override { }


  virtual void enterEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void exitEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void visitTerminal(antlr4::tree::TerminalNode * /*node*/) override { }
  virtual void visitErrorNode(antlr4::tree::ErrorNode * /*node*/) override { }

};

