
// Generated from Expr.g4 by ANTLR 4.7.1

#pragma once


#include "antlr4-runtime.h"
#include "ExprParser.h"


/**
 * This interface defines an abstract listener for a parse tree produced by ExprParser.
 */
class  ExprListener : public antlr4::tree::ParseTreeListener {
public:

  virtual void enterProg(ExprParser::ProgContext *ctx) = 0;
  virtual void exitProg(ExprParser::ProgContext *ctx) = 0;

  virtual void enterStat(ExprParser::StatContext *ctx) = 0;
  virtual void exitStat(ExprParser::StatContext *ctx) = 0;

  virtual void enterIf_stat(ExprParser::If_statContext *ctx) = 0;
  virtual void exitIf_stat(ExprParser::If_statContext *ctx) = 0;

  virtual void enterWhile_stat(ExprParser::While_statContext *ctx) = 0;
  virtual void exitWhile_stat(ExprParser::While_statContext *ctx) = 0;

  virtual void enterFunction(ExprParser::FunctionContext *ctx) = 0;
  virtual void exitFunction(ExprParser::FunctionContext *ctx) = 0;

  virtual void enterFunc_call(ExprParser::Func_callContext *ctx) = 0;
  virtual void exitFunc_call(ExprParser::Func_callContext *ctx) = 0;

  virtual void enterExpr(ExprParser::ExprContext *ctx) = 0;
  virtual void exitExpr(ExprParser::ExprContext *ctx) = 0;

  virtual void enterVar_dec(ExprParser::Var_decContext *ctx) = 0;
  virtual void exitVar_dec(ExprParser::Var_decContext *ctx) = 0;

  virtual void enterFunc_synt(ExprParser::Func_syntContext *ctx) = 0;
  virtual void exitFunc_synt(ExprParser::Func_syntContext *ctx) = 0;


};

