
// Generated from Expr.g4 by ANTLR 4.7.1


#include "ExprListener.h"

#include "ExprParser.h"


using namespace antlrcpp;
using namespace antlr4;

ExprParser::ExprParser(TokenStream *input) : Parser(input) {
  _interpreter = new atn::ParserATNSimulator(this, _atn, _decisionToDFA, _sharedContextCache);
}

ExprParser::~ExprParser() {
  delete _interpreter;
}

std::string ExprParser::getGrammarFileName() const {
  return "Expr.g4";
}

const std::vector<std::string>& ExprParser::getRuleNames() const {
  return _ruleNames;
}

dfa::Vocabulary& ExprParser::getVocabulary() const {
  return _vocabulary;
}


//----------------- ProgContext ------------------------------------------------------------------

ExprParser::ProgContext::ProgContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<ExprParser::StatContext *> ExprParser::ProgContext::stat() {
  return getRuleContexts<ExprParser::StatContext>();
}

ExprParser::StatContext* ExprParser::ProgContext::stat(size_t i) {
  return getRuleContext<ExprParser::StatContext>(i);
}


size_t ExprParser::ProgContext::getRuleIndex() const {
  return ExprParser::RuleProg;
}

void ExprParser::ProgContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<ExprListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProg(this);
}

void ExprParser::ProgContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<ExprListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProg(this);
}

ExprParser::ProgContext* ExprParser::prog() {
  ProgContext *_localctx = _tracker.createInstance<ProgContext>(_ctx, getState());
  enterRule(_localctx, 0, ExprParser::RuleProg);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(19); 
    _errHandler->sync(this);
    _la = _input->LA(1);
    do {
      setState(18);
      stat();
      setState(21); 
      _errHandler->sync(this);
      _la = _input->LA(1);
    } while ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << ExprParser::T__2)
      | (1ULL << ExprParser::T__4)
      | (1ULL << ExprParser::T__5)
      | (1ULL << ExprParser::T__7)
      | (1ULL << ExprParser::T__17)
      | (1ULL << ExprParser::T__19)
      | (1ULL << ExprParser::T__21)
      | (1ULL << ExprParser::T__22)
      | (1ULL << ExprParser::T__23)
      | (1ULL << ExprParser::ID)
      | (1ULL << ExprParser::INT)
      | (1ULL << ExprParser::BOOL))) != 0));
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- StatContext ------------------------------------------------------------------

ExprParser::StatContext::StatContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

ExprParser::ExprContext* ExprParser::StatContext::expr() {
  return getRuleContext<ExprParser::ExprContext>(0);
}

tree::TerminalNode* ExprParser::StatContext::ID() {
  return getToken(ExprParser::ID, 0);
}

std::vector<ExprParser::StatContext *> ExprParser::StatContext::stat() {
  return getRuleContexts<ExprParser::StatContext>();
}

ExprParser::StatContext* ExprParser::StatContext::stat(size_t i) {
  return getRuleContext<ExprParser::StatContext>(i);
}

ExprParser::Var_decContext* ExprParser::StatContext::var_dec() {
  return getRuleContext<ExprParser::Var_decContext>(0);
}

ExprParser::If_statContext* ExprParser::StatContext::if_stat() {
  return getRuleContext<ExprParser::If_statContext>(0);
}

ExprParser::While_statContext* ExprParser::StatContext::while_stat() {
  return getRuleContext<ExprParser::While_statContext>(0);
}

ExprParser::FunctionContext* ExprParser::StatContext::function() {
  return getRuleContext<ExprParser::FunctionContext>(0);
}

ExprParser::Func_callContext* ExprParser::StatContext::func_call() {
  return getRuleContext<ExprParser::Func_callContext>(0);
}


size_t ExprParser::StatContext::getRuleIndex() const {
  return ExprParser::RuleStat;
}

void ExprParser::StatContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<ExprListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStat(this);
}

void ExprParser::StatContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<ExprListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStat(this);
}

ExprParser::StatContext* ExprParser::stat() {
  StatContext *_localctx = _tracker.createInstance<StatContext>(_ctx, getState());
  enterRule(_localctx, 2, ExprParser::RuleStat);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(57);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 5, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(23);
      expr(0);
      setState(24);
      match(ExprParser::T__0);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(26);
      match(ExprParser::ID);
      setState(27);
      match(ExprParser::T__1);
      setState(28);
      expr(0);
      setState(29);
      match(ExprParser::T__0);
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(31);
      match(ExprParser::T__2);
      setState(37);
      _errHandler->sync(this);

      switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 1, _ctx)) {
      case 1: {
        setState(32);
        match(ExprParser::ID);
        setState(33);
        match(ExprParser::T__1);
        setState(34);
        expr(0);
        setState(35);
        match(ExprParser::T__0);
        break;
      }

      }
      setState(44);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if ((((_la & ~ 0x3fULL) == 0) &&
        ((1ULL << _la) & ((1ULL << ExprParser::T__2)
        | (1ULL << ExprParser::T__4)
        | (1ULL << ExprParser::T__5)
        | (1ULL << ExprParser::T__7)
        | (1ULL << ExprParser::T__17)
        | (1ULL << ExprParser::T__19)
        | (1ULL << ExprParser::T__21)
        | (1ULL << ExprParser::T__22)
        | (1ULL << ExprParser::T__23)
        | (1ULL << ExprParser::ID)
        | (1ULL << ExprParser::INT)
        | (1ULL << ExprParser::BOOL))) != 0)) {
        setState(40); 
        _errHandler->sync(this);
        _la = _input->LA(1);
        do {
          setState(39);
          stat();
          setState(42); 
          _errHandler->sync(this);
          _la = _input->LA(1);
        } while ((((_la & ~ 0x3fULL) == 0) &&
          ((1ULL << _la) & ((1ULL << ExprParser::T__2)
          | (1ULL << ExprParser::T__4)
          | (1ULL << ExprParser::T__5)
          | (1ULL << ExprParser::T__7)
          | (1ULL << ExprParser::T__17)
          | (1ULL << ExprParser::T__19)
          | (1ULL << ExprParser::T__21)
          | (1ULL << ExprParser::T__22)
          | (1ULL << ExprParser::T__23)
          | (1ULL << ExprParser::ID)
          | (1ULL << ExprParser::INT)
          | (1ULL << ExprParser::BOOL))) != 0));
      }
      setState(46);
      match(ExprParser::T__3);
      break;
    }

    case 4: {
      enterOuterAlt(_localctx, 4);
      setState(47);
      var_dec();
      break;
    }

    case 5: {
      enterOuterAlt(_localctx, 5);
      setState(48);
      if_stat();
      break;
    }

    case 6: {
      enterOuterAlt(_localctx, 6);
      setState(49);
      while_stat();
      break;
    }

    case 7: {
      enterOuterAlt(_localctx, 7);
      setState(50);
      function();
      break;
    }

    case 8: {
      enterOuterAlt(_localctx, 8);
      setState(51);
      func_call();
      break;
    }

    case 9: {
      enterOuterAlt(_localctx, 9);
      setState(52);
      match(ExprParser::T__4);
      setState(54);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if ((((_la & ~ 0x3fULL) == 0) &&
        ((1ULL << _la) & ((1ULL << ExprParser::T__17)
        | (1ULL << ExprParser::T__19)
        | (1ULL << ExprParser::ID)
        | (1ULL << ExprParser::INT)
        | (1ULL << ExprParser::BOOL))) != 0)) {
        setState(53);
        expr(0);
      }
      setState(56);
      match(ExprParser::T__0);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- If_statContext ------------------------------------------------------------------

ExprParser::If_statContext::If_statContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

ExprParser::ExprContext* ExprParser::If_statContext::expr() {
  return getRuleContext<ExprParser::ExprContext>(0);
}

std::vector<ExprParser::StatContext *> ExprParser::If_statContext::stat() {
  return getRuleContexts<ExprParser::StatContext>();
}

ExprParser::StatContext* ExprParser::If_statContext::stat(size_t i) {
  return getRuleContext<ExprParser::StatContext>(i);
}


size_t ExprParser::If_statContext::getRuleIndex() const {
  return ExprParser::RuleIf_stat;
}

void ExprParser::If_statContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<ExprListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterIf_stat(this);
}

void ExprParser::If_statContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<ExprListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitIf_stat(this);
}

ExprParser::If_statContext* ExprParser::if_stat() {
  If_statContext *_localctx = _tracker.createInstance<If_statContext>(_ctx, getState());
  enterRule(_localctx, 4, ExprParser::RuleIf_stat);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(59);
    match(ExprParser::T__5);
    setState(60);
    expr(0);
    setState(61);
    stat();
    setState(64);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 6, _ctx)) {
    case 1: {
      setState(62);
      match(ExprParser::T__6);
      setState(63);
      stat();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- While_statContext ------------------------------------------------------------------

ExprParser::While_statContext::While_statContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

ExprParser::ExprContext* ExprParser::While_statContext::expr() {
  return getRuleContext<ExprParser::ExprContext>(0);
}

ExprParser::StatContext* ExprParser::While_statContext::stat() {
  return getRuleContext<ExprParser::StatContext>(0);
}


size_t ExprParser::While_statContext::getRuleIndex() const {
  return ExprParser::RuleWhile_stat;
}

void ExprParser::While_statContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<ExprListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterWhile_stat(this);
}

void ExprParser::While_statContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<ExprListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitWhile_stat(this);
}

ExprParser::While_statContext* ExprParser::while_stat() {
  While_statContext *_localctx = _tracker.createInstance<While_statContext>(_ctx, getState());
  enterRule(_localctx, 6, ExprParser::RuleWhile_stat);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(66);
    match(ExprParser::T__7);
    setState(67);
    expr(0);
    setState(68);
    stat();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- FunctionContext ------------------------------------------------------------------

ExprParser::FunctionContext::FunctionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

ExprParser::Func_syntContext* ExprParser::FunctionContext::func_synt() {
  return getRuleContext<ExprParser::Func_syntContext>(0);
}

tree::TerminalNode* ExprParser::FunctionContext::ID() {
  return getToken(ExprParser::ID, 0);
}

ExprParser::StatContext* ExprParser::FunctionContext::stat() {
  return getRuleContext<ExprParser::StatContext>(0);
}

ExprParser::ExprContext* ExprParser::FunctionContext::expr() {
  return getRuleContext<ExprParser::ExprContext>(0);
}


size_t ExprParser::FunctionContext::getRuleIndex() const {
  return ExprParser::RuleFunction;
}

void ExprParser::FunctionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<ExprListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterFunction(this);
}

void ExprParser::FunctionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<ExprListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitFunction(this);
}

ExprParser::FunctionContext* ExprParser::function() {
  FunctionContext *_localctx = _tracker.createInstance<FunctionContext>(_ctx, getState());
  enterRule(_localctx, 8, ExprParser::RuleFunction);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(70);
    func_synt();
    setState(71);
    match(ExprParser::ID);
    setState(73);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 7, _ctx)) {
    case 1: {
      setState(72);
      expr(0);
      break;
    }

    }
    setState(75);
    stat();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Func_callContext ------------------------------------------------------------------

ExprParser::Func_callContext::Func_callContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* ExprParser::Func_callContext::ID() {
  return getToken(ExprParser::ID, 0);
}

ExprParser::ExprContext* ExprParser::Func_callContext::expr() {
  return getRuleContext<ExprParser::ExprContext>(0);
}


size_t ExprParser::Func_callContext::getRuleIndex() const {
  return ExprParser::RuleFunc_call;
}

void ExprParser::Func_callContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<ExprListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterFunc_call(this);
}

void ExprParser::Func_callContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<ExprListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitFunc_call(this);
}

ExprParser::Func_callContext* ExprParser::func_call() {
  Func_callContext *_localctx = _tracker.createInstance<Func_callContext>(_ctx, getState());
  enterRule(_localctx, 10, ExprParser::RuleFunc_call);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(77);
    match(ExprParser::ID);
    setState(78);
    expr(0);
    setState(79);
    match(ExprParser::T__0);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExprContext ------------------------------------------------------------------

ExprParser::ExprContext::ExprContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* ExprParser::ExprContext::INT() {
  return getToken(ExprParser::INT, 0);
}

std::vector<ExprParser::ExprContext *> ExprParser::ExprContext::expr() {
  return getRuleContexts<ExprParser::ExprContext>();
}

ExprParser::ExprContext* ExprParser::ExprContext::expr(size_t i) {
  return getRuleContext<ExprParser::ExprContext>(i);
}

tree::TerminalNode* ExprParser::ExprContext::ID() {
  return getToken(ExprParser::ID, 0);
}

tree::TerminalNode* ExprParser::ExprContext::BOOL() {
  return getToken(ExprParser::BOOL, 0);
}


size_t ExprParser::ExprContext::getRuleIndex() const {
  return ExprParser::RuleExpr;
}

void ExprParser::ExprContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<ExprListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterExpr(this);
}

void ExprParser::ExprContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<ExprListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitExpr(this);
}


ExprParser::ExprContext* ExprParser::expr() {
   return expr(0);
}

ExprParser::ExprContext* ExprParser::expr(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  ExprParser::ExprContext *_localctx = _tracker.createInstance<ExprContext>(_ctx, parentState);
  ExprParser::ExprContext *previousContext = _localctx;
  size_t startState = 12;
  enterRecursionRule(_localctx, 12, ExprParser::RuleExpr, precedence);

    size_t _la = 0;

  auto onExit = finally([=] {
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(119);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 17, _ctx)) {
    case 1: {
      setState(83);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == ExprParser::T__17) {
        setState(82);
        match(ExprParser::T__17);
      }
      setState(85);
      match(ExprParser::INT);
      setState(91);
      _errHandler->sync(this);

      switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 10, _ctx)) {
      case 1: {
        setState(86);
        match(ExprParser::T__18);
        setState(88);
        _errHandler->sync(this);

        switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 9, _ctx)) {
        case 1: {
          setState(87);
          match(ExprParser::T__17);
          break;
        }

        }
        setState(90);
        expr(0);
        break;
      }

      }
      break;
    }

    case 2: {
      setState(94);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == ExprParser::T__17) {
        setState(93);
        match(ExprParser::T__17);
      }
      setState(96);
      match(ExprParser::ID);
      setState(102);
      _errHandler->sync(this);

      switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 13, _ctx)) {
      case 1: {
        setState(97);
        match(ExprParser::T__18);
        setState(99);
        _errHandler->sync(this);

        switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 12, _ctx)) {
        case 1: {
          setState(98);
          match(ExprParser::T__17);
          break;
        }

        }
        setState(101);
        expr(0);
        break;
      }

      }
      break;
    }

    case 3: {
      setState(105);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == ExprParser::T__17) {
        setState(104);
        match(ExprParser::T__17);
      }
      setState(107);
      match(ExprParser::BOOL);
      setState(113);
      _errHandler->sync(this);

      switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 16, _ctx)) {
      case 1: {
        setState(108);
        match(ExprParser::T__18);
        setState(110);
        _errHandler->sync(this);

        switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 15, _ctx)) {
        case 1: {
          setState(109);
          match(ExprParser::T__17);
          break;
        }

        }
        setState(112);
        expr(0);
        break;
      }

      }
      break;
    }

    case 4: {
      setState(115);
      match(ExprParser::T__19);
      setState(116);
      expr(0);
      setState(117);
      match(ExprParser::T__20);
      break;
    }

    }
    _ctx->stop = _input->LT(-1);
    setState(132);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 19, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        setState(130);
        _errHandler->sync(this);
        switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 18, _ctx)) {
        case 1: {
          _localctx = _tracker.createInstance<ExprContext>(parentContext, parentState);
          pushNewRecursionContext(_localctx, startState, RuleExpr);
          setState(121);

          if (!(precpred(_ctx, 7))) throw FailedPredicateException(this, "precpred(_ctx, 7)");
          setState(122);
          _la = _input->LA(1);
          if (!(_la == ExprParser::T__8

          || _la == ExprParser::T__9)) {
          _errHandler->recoverInline(this);
          }
          else {
            _errHandler->reportMatch(this);
            consume();
          }
          setState(123);
          expr(8);
          break;
        }

        case 2: {
          _localctx = _tracker.createInstance<ExprContext>(parentContext, parentState);
          pushNewRecursionContext(_localctx, startState, RuleExpr);
          setState(124);

          if (!(precpred(_ctx, 6))) throw FailedPredicateException(this, "precpred(_ctx, 6)");
          setState(125);
          _la = _input->LA(1);
          if (!(_la == ExprParser::T__10

          || _la == ExprParser::T__11)) {
          _errHandler->recoverInline(this);
          }
          else {
            _errHandler->reportMatch(this);
            consume();
          }
          setState(126);
          expr(7);
          break;
        }

        case 3: {
          _localctx = _tracker.createInstance<ExprContext>(parentContext, parentState);
          pushNewRecursionContext(_localctx, startState, RuleExpr);
          setState(127);

          if (!(precpred(_ctx, 5))) throw FailedPredicateException(this, "precpred(_ctx, 5)");
          setState(128);
          _la = _input->LA(1);
          if (!((((_la & ~ 0x3fULL) == 0) &&
            ((1ULL << _la) & ((1ULL << ExprParser::T__12)
            | (1ULL << ExprParser::T__13)
            | (1ULL << ExprParser::T__14)
            | (1ULL << ExprParser::T__15)
            | (1ULL << ExprParser::T__16))) != 0))) {
          _errHandler->recoverInline(this);
          }
          else {
            _errHandler->reportMatch(this);
            consume();
          }
          setState(129);
          expr(6);
          break;
        }

        } 
      }
      setState(134);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 19, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

//----------------- Var_decContext ------------------------------------------------------------------

ExprParser::Var_decContext::Var_decContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<ExprParser::ExprContext *> ExprParser::Var_decContext::expr() {
  return getRuleContexts<ExprParser::ExprContext>();
}

ExprParser::ExprContext* ExprParser::Var_decContext::expr(size_t i) {
  return getRuleContext<ExprParser::ExprContext>(i);
}


size_t ExprParser::Var_decContext::getRuleIndex() const {
  return ExprParser::RuleVar_dec;
}

void ExprParser::Var_decContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<ExprListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVar_dec(this);
}

void ExprParser::Var_decContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<ExprListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVar_dec(this);
}

ExprParser::Var_decContext* ExprParser::var_dec() {
  Var_decContext *_localctx = _tracker.createInstance<Var_decContext>(_ctx, getState());
  enterRule(_localctx, 14, ExprParser::RuleVar_dec);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(151);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case ExprParser::T__21: {
        enterOuterAlt(_localctx, 1);
        setState(135);
        match(ExprParser::T__21);
        setState(136);
        expr(0);
        setState(139);
        _errHandler->sync(this);

        _la = _input->LA(1);
        if (_la == ExprParser::T__1) {
          setState(137);
          match(ExprParser::T__1);
          setState(138);
          expr(0);
        }
        setState(141);
        match(ExprParser::T__0);
        break;
      }

      case ExprParser::T__22: {
        enterOuterAlt(_localctx, 2);
        setState(143);
        match(ExprParser::T__22);
        setState(144);
        expr(0);
        setState(147);
        _errHandler->sync(this);

        _la = _input->LA(1);
        if (_la == ExprParser::T__1) {
          setState(145);
          match(ExprParser::T__1);
          setState(146);
          expr(0);
        }
        setState(149);
        match(ExprParser::T__0);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Func_syntContext ------------------------------------------------------------------

ExprParser::Func_syntContext::Func_syntContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t ExprParser::Func_syntContext::getRuleIndex() const {
  return ExprParser::RuleFunc_synt;
}

void ExprParser::Func_syntContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<ExprListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterFunc_synt(this);
}

void ExprParser::Func_syntContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<ExprListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitFunc_synt(this);
}

ExprParser::Func_syntContext* ExprParser::func_synt() {
  Func_syntContext *_localctx = _tracker.createInstance<Func_syntContext>(_ctx, getState());
  enterRule(_localctx, 16, ExprParser::RuleFunc_synt);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(153);
    _la = _input->LA(1);
    if (!((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << ExprParser::T__21)
      | (1ULL << ExprParser::T__22)
      | (1ULL << ExprParser::T__23))) != 0))) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

bool ExprParser::sempred(RuleContext *context, size_t ruleIndex, size_t predicateIndex) {
  switch (ruleIndex) {
    case 6: return exprSempred(dynamic_cast<ExprContext *>(context), predicateIndex);

  default:
    break;
  }
  return true;
}

bool ExprParser::exprSempred(ExprContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 0: return precpred(_ctx, 7);
    case 1: return precpred(_ctx, 6);
    case 2: return precpred(_ctx, 5);

  default:
    break;
  }
  return true;
}

// Static vars and initialization.
std::vector<dfa::DFA> ExprParser::_decisionToDFA;
atn::PredictionContextCache ExprParser::_sharedContextCache;

// We own the ATN which in turn owns the ATN states.
atn::ATN ExprParser::_atn;
std::vector<uint16_t> ExprParser::_serializedATN;

std::vector<std::string> ExprParser::_ruleNames = {
  "prog", "stat", "if_stat", "while_stat", "function", "func_call", "expr", 
  "var_dec", "func_synt"
};

std::vector<std::string> ExprParser::_literalNames = {
  "", "';'", "'='", "'{'", "'}'", "'return'", "'if'", "'else'", "'while'", 
  "'*'", "'/'", "'+'", "'-'", "'=='", "'>='", "'<='", "'>'", "'<'", "'#'", 
  "','", "'('", "')'", "'int'", "'bool'", "'void'"
};

std::vector<std::string> ExprParser::_symbolicNames = {
  "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", 
  "", "", "", "", "", "", "", "ID", "INT", "BOOL", "WS"
};

dfa::Vocabulary ExprParser::_vocabulary(_literalNames, _symbolicNames);

std::vector<std::string> ExprParser::_tokenNames;

ExprParser::Initializer::Initializer() {
	for (size_t i = 0; i < _symbolicNames.size(); ++i) {
		std::string name = _vocabulary.getLiteralName(i);
		if (name.empty()) {
			name = _vocabulary.getSymbolicName(i);
		}

		if (name.empty()) {
			_tokenNames.push_back("<INVALID>");
		} else {
      _tokenNames.push_back(name);
    }
	}

  _serializedATN = {
    0x3, 0x608b, 0xa72a, 0x8133, 0xb9ed, 0x417c, 0x3be7, 0x7786, 0x5964, 
    0x3, 0x1e, 0x9e, 0x4, 0x2, 0x9, 0x2, 0x4, 0x3, 0x9, 0x3, 0x4, 0x4, 0x9, 
    0x4, 0x4, 0x5, 0x9, 0x5, 0x4, 0x6, 0x9, 0x6, 0x4, 0x7, 0x9, 0x7, 0x4, 
    0x8, 0x9, 0x8, 0x4, 0x9, 0x9, 0x9, 0x4, 0xa, 0x9, 0xa, 0x3, 0x2, 0x6, 
    0x2, 0x16, 0xa, 0x2, 0xd, 0x2, 0xe, 0x2, 0x17, 0x3, 0x3, 0x3, 0x3, 0x3, 
    0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 
    0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x5, 0x3, 0x28, 0xa, 0x3, 
    0x3, 0x3, 0x6, 0x3, 0x2b, 0xa, 0x3, 0xd, 0x3, 0xe, 0x3, 0x2c, 0x5, 0x3, 
    0x2f, 0xa, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 
    0x3, 0x3, 0x3, 0x3, 0x3, 0x5, 0x3, 0x39, 0xa, 0x3, 0x3, 0x3, 0x5, 0x3, 
    0x3c, 0xa, 0x3, 0x3, 0x4, 0x3, 0x4, 0x3, 0x4, 0x3, 0x4, 0x3, 0x4, 0x5, 
    0x4, 0x43, 0xa, 0x4, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x6, 
    0x3, 0x6, 0x3, 0x6, 0x5, 0x6, 0x4c, 0xa, 0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 
    0x7, 0x3, 0x7, 0x3, 0x7, 0x3, 0x7, 0x3, 0x8, 0x3, 0x8, 0x5, 0x8, 0x56, 
    0xa, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x5, 0x8, 0x5b, 0xa, 0x8, 0x3, 
    0x8, 0x5, 0x8, 0x5e, 0xa, 0x8, 0x3, 0x8, 0x5, 0x8, 0x61, 0xa, 0x8, 0x3, 
    0x8, 0x3, 0x8, 0x3, 0x8, 0x5, 0x8, 0x66, 0xa, 0x8, 0x3, 0x8, 0x5, 0x8, 
    0x69, 0xa, 0x8, 0x3, 0x8, 0x5, 0x8, 0x6c, 0xa, 0x8, 0x3, 0x8, 0x3, 0x8, 
    0x3, 0x8, 0x5, 0x8, 0x71, 0xa, 0x8, 0x3, 0x8, 0x5, 0x8, 0x74, 0xa, 0x8, 
    0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x5, 0x8, 0x7a, 0xa, 0x8, 0x3, 
    0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 
    0x8, 0x3, 0x8, 0x7, 0x8, 0x85, 0xa, 0x8, 0xc, 0x8, 0xe, 0x8, 0x88, 0xb, 
    0x8, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x5, 0x9, 0x8e, 0xa, 0x9, 
    0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x5, 0x9, 
    0x96, 0xa, 0x9, 0x3, 0x9, 0x3, 0x9, 0x5, 0x9, 0x9a, 0xa, 0x9, 0x3, 0xa, 
    0x3, 0xa, 0x3, 0xa, 0x2, 0x3, 0xe, 0xb, 0x2, 0x4, 0x6, 0x8, 0xa, 0xc, 
    0xe, 0x10, 0x12, 0x2, 0x6, 0x3, 0x2, 0xb, 0xc, 0x3, 0x2, 0xd, 0xe, 0x3, 
    0x2, 0xf, 0x13, 0x3, 0x2, 0x18, 0x1a, 0x2, 0xb5, 0x2, 0x15, 0x3, 0x2, 
    0x2, 0x2, 0x4, 0x3b, 0x3, 0x2, 0x2, 0x2, 0x6, 0x3d, 0x3, 0x2, 0x2, 0x2, 
    0x8, 0x44, 0x3, 0x2, 0x2, 0x2, 0xa, 0x48, 0x3, 0x2, 0x2, 0x2, 0xc, 0x4f, 
    0x3, 0x2, 0x2, 0x2, 0xe, 0x79, 0x3, 0x2, 0x2, 0x2, 0x10, 0x99, 0x3, 
    0x2, 0x2, 0x2, 0x12, 0x9b, 0x3, 0x2, 0x2, 0x2, 0x14, 0x16, 0x5, 0x4, 
    0x3, 0x2, 0x15, 0x14, 0x3, 0x2, 0x2, 0x2, 0x16, 0x17, 0x3, 0x2, 0x2, 
    0x2, 0x17, 0x15, 0x3, 0x2, 0x2, 0x2, 0x17, 0x18, 0x3, 0x2, 0x2, 0x2, 
    0x18, 0x3, 0x3, 0x2, 0x2, 0x2, 0x19, 0x1a, 0x5, 0xe, 0x8, 0x2, 0x1a, 
    0x1b, 0x7, 0x3, 0x2, 0x2, 0x1b, 0x3c, 0x3, 0x2, 0x2, 0x2, 0x1c, 0x1d, 
    0x7, 0x1b, 0x2, 0x2, 0x1d, 0x1e, 0x7, 0x4, 0x2, 0x2, 0x1e, 0x1f, 0x5, 
    0xe, 0x8, 0x2, 0x1f, 0x20, 0x7, 0x3, 0x2, 0x2, 0x20, 0x3c, 0x3, 0x2, 
    0x2, 0x2, 0x21, 0x27, 0x7, 0x5, 0x2, 0x2, 0x22, 0x23, 0x7, 0x1b, 0x2, 
    0x2, 0x23, 0x24, 0x7, 0x4, 0x2, 0x2, 0x24, 0x25, 0x5, 0xe, 0x8, 0x2, 
    0x25, 0x26, 0x7, 0x3, 0x2, 0x2, 0x26, 0x28, 0x3, 0x2, 0x2, 0x2, 0x27, 
    0x22, 0x3, 0x2, 0x2, 0x2, 0x27, 0x28, 0x3, 0x2, 0x2, 0x2, 0x28, 0x2e, 
    0x3, 0x2, 0x2, 0x2, 0x29, 0x2b, 0x5, 0x4, 0x3, 0x2, 0x2a, 0x29, 0x3, 
    0x2, 0x2, 0x2, 0x2b, 0x2c, 0x3, 0x2, 0x2, 0x2, 0x2c, 0x2a, 0x3, 0x2, 
    0x2, 0x2, 0x2c, 0x2d, 0x3, 0x2, 0x2, 0x2, 0x2d, 0x2f, 0x3, 0x2, 0x2, 
    0x2, 0x2e, 0x2a, 0x3, 0x2, 0x2, 0x2, 0x2e, 0x2f, 0x3, 0x2, 0x2, 0x2, 
    0x2f, 0x30, 0x3, 0x2, 0x2, 0x2, 0x30, 0x3c, 0x7, 0x6, 0x2, 0x2, 0x31, 
    0x3c, 0x5, 0x10, 0x9, 0x2, 0x32, 0x3c, 0x5, 0x6, 0x4, 0x2, 0x33, 0x3c, 
    0x5, 0x8, 0x5, 0x2, 0x34, 0x3c, 0x5, 0xa, 0x6, 0x2, 0x35, 0x3c, 0x5, 
    0xc, 0x7, 0x2, 0x36, 0x38, 0x7, 0x7, 0x2, 0x2, 0x37, 0x39, 0x5, 0xe, 
    0x8, 0x2, 0x38, 0x37, 0x3, 0x2, 0x2, 0x2, 0x38, 0x39, 0x3, 0x2, 0x2, 
    0x2, 0x39, 0x3a, 0x3, 0x2, 0x2, 0x2, 0x3a, 0x3c, 0x7, 0x3, 0x2, 0x2, 
    0x3b, 0x19, 0x3, 0x2, 0x2, 0x2, 0x3b, 0x1c, 0x3, 0x2, 0x2, 0x2, 0x3b, 
    0x21, 0x3, 0x2, 0x2, 0x2, 0x3b, 0x31, 0x3, 0x2, 0x2, 0x2, 0x3b, 0x32, 
    0x3, 0x2, 0x2, 0x2, 0x3b, 0x33, 0x3, 0x2, 0x2, 0x2, 0x3b, 0x34, 0x3, 
    0x2, 0x2, 0x2, 0x3b, 0x35, 0x3, 0x2, 0x2, 0x2, 0x3b, 0x36, 0x3, 0x2, 
    0x2, 0x2, 0x3c, 0x5, 0x3, 0x2, 0x2, 0x2, 0x3d, 0x3e, 0x7, 0x8, 0x2, 
    0x2, 0x3e, 0x3f, 0x5, 0xe, 0x8, 0x2, 0x3f, 0x42, 0x5, 0x4, 0x3, 0x2, 
    0x40, 0x41, 0x7, 0x9, 0x2, 0x2, 0x41, 0x43, 0x5, 0x4, 0x3, 0x2, 0x42, 
    0x40, 0x3, 0x2, 0x2, 0x2, 0x42, 0x43, 0x3, 0x2, 0x2, 0x2, 0x43, 0x7, 
    0x3, 0x2, 0x2, 0x2, 0x44, 0x45, 0x7, 0xa, 0x2, 0x2, 0x45, 0x46, 0x5, 
    0xe, 0x8, 0x2, 0x46, 0x47, 0x5, 0x4, 0x3, 0x2, 0x47, 0x9, 0x3, 0x2, 
    0x2, 0x2, 0x48, 0x49, 0x5, 0x12, 0xa, 0x2, 0x49, 0x4b, 0x7, 0x1b, 0x2, 
    0x2, 0x4a, 0x4c, 0x5, 0xe, 0x8, 0x2, 0x4b, 0x4a, 0x3, 0x2, 0x2, 0x2, 
    0x4b, 0x4c, 0x3, 0x2, 0x2, 0x2, 0x4c, 0x4d, 0x3, 0x2, 0x2, 0x2, 0x4d, 
    0x4e, 0x5, 0x4, 0x3, 0x2, 0x4e, 0xb, 0x3, 0x2, 0x2, 0x2, 0x4f, 0x50, 
    0x7, 0x1b, 0x2, 0x2, 0x50, 0x51, 0x5, 0xe, 0x8, 0x2, 0x51, 0x52, 0x7, 
    0x3, 0x2, 0x2, 0x52, 0xd, 0x3, 0x2, 0x2, 0x2, 0x53, 0x55, 0x8, 0x8, 
    0x1, 0x2, 0x54, 0x56, 0x7, 0x14, 0x2, 0x2, 0x55, 0x54, 0x3, 0x2, 0x2, 
    0x2, 0x55, 0x56, 0x3, 0x2, 0x2, 0x2, 0x56, 0x57, 0x3, 0x2, 0x2, 0x2, 
    0x57, 0x5d, 0x7, 0x1c, 0x2, 0x2, 0x58, 0x5a, 0x7, 0x15, 0x2, 0x2, 0x59, 
    0x5b, 0x7, 0x14, 0x2, 0x2, 0x5a, 0x59, 0x3, 0x2, 0x2, 0x2, 0x5a, 0x5b, 
    0x3, 0x2, 0x2, 0x2, 0x5b, 0x5c, 0x3, 0x2, 0x2, 0x2, 0x5c, 0x5e, 0x5, 
    0xe, 0x8, 0x2, 0x5d, 0x58, 0x3, 0x2, 0x2, 0x2, 0x5d, 0x5e, 0x3, 0x2, 
    0x2, 0x2, 0x5e, 0x7a, 0x3, 0x2, 0x2, 0x2, 0x5f, 0x61, 0x7, 0x14, 0x2, 
    0x2, 0x60, 0x5f, 0x3, 0x2, 0x2, 0x2, 0x60, 0x61, 0x3, 0x2, 0x2, 0x2, 
    0x61, 0x62, 0x3, 0x2, 0x2, 0x2, 0x62, 0x68, 0x7, 0x1b, 0x2, 0x2, 0x63, 
    0x65, 0x7, 0x15, 0x2, 0x2, 0x64, 0x66, 0x7, 0x14, 0x2, 0x2, 0x65, 0x64, 
    0x3, 0x2, 0x2, 0x2, 0x65, 0x66, 0x3, 0x2, 0x2, 0x2, 0x66, 0x67, 0x3, 
    0x2, 0x2, 0x2, 0x67, 0x69, 0x5, 0xe, 0x8, 0x2, 0x68, 0x63, 0x3, 0x2, 
    0x2, 0x2, 0x68, 0x69, 0x3, 0x2, 0x2, 0x2, 0x69, 0x7a, 0x3, 0x2, 0x2, 
    0x2, 0x6a, 0x6c, 0x7, 0x14, 0x2, 0x2, 0x6b, 0x6a, 0x3, 0x2, 0x2, 0x2, 
    0x6b, 0x6c, 0x3, 0x2, 0x2, 0x2, 0x6c, 0x6d, 0x3, 0x2, 0x2, 0x2, 0x6d, 
    0x73, 0x7, 0x1d, 0x2, 0x2, 0x6e, 0x70, 0x7, 0x15, 0x2, 0x2, 0x6f, 0x71, 
    0x7, 0x14, 0x2, 0x2, 0x70, 0x6f, 0x3, 0x2, 0x2, 0x2, 0x70, 0x71, 0x3, 
    0x2, 0x2, 0x2, 0x71, 0x72, 0x3, 0x2, 0x2, 0x2, 0x72, 0x74, 0x5, 0xe, 
    0x8, 0x2, 0x73, 0x6e, 0x3, 0x2, 0x2, 0x2, 0x73, 0x74, 0x3, 0x2, 0x2, 
    0x2, 0x74, 0x7a, 0x3, 0x2, 0x2, 0x2, 0x75, 0x76, 0x7, 0x16, 0x2, 0x2, 
    0x76, 0x77, 0x5, 0xe, 0x8, 0x2, 0x77, 0x78, 0x7, 0x17, 0x2, 0x2, 0x78, 
    0x7a, 0x3, 0x2, 0x2, 0x2, 0x79, 0x53, 0x3, 0x2, 0x2, 0x2, 0x79, 0x60, 
    0x3, 0x2, 0x2, 0x2, 0x79, 0x6b, 0x3, 0x2, 0x2, 0x2, 0x79, 0x75, 0x3, 
    0x2, 0x2, 0x2, 0x7a, 0x86, 0x3, 0x2, 0x2, 0x2, 0x7b, 0x7c, 0xc, 0x9, 
    0x2, 0x2, 0x7c, 0x7d, 0x9, 0x2, 0x2, 0x2, 0x7d, 0x85, 0x5, 0xe, 0x8, 
    0xa, 0x7e, 0x7f, 0xc, 0x8, 0x2, 0x2, 0x7f, 0x80, 0x9, 0x3, 0x2, 0x2, 
    0x80, 0x85, 0x5, 0xe, 0x8, 0x9, 0x81, 0x82, 0xc, 0x7, 0x2, 0x2, 0x82, 
    0x83, 0x9, 0x4, 0x2, 0x2, 0x83, 0x85, 0x5, 0xe, 0x8, 0x8, 0x84, 0x7b, 
    0x3, 0x2, 0x2, 0x2, 0x84, 0x7e, 0x3, 0x2, 0x2, 0x2, 0x84, 0x81, 0x3, 
    0x2, 0x2, 0x2, 0x85, 0x88, 0x3, 0x2, 0x2, 0x2, 0x86, 0x84, 0x3, 0x2, 
    0x2, 0x2, 0x86, 0x87, 0x3, 0x2, 0x2, 0x2, 0x87, 0xf, 0x3, 0x2, 0x2, 
    0x2, 0x88, 0x86, 0x3, 0x2, 0x2, 0x2, 0x89, 0x8a, 0x7, 0x18, 0x2, 0x2, 
    0x8a, 0x8d, 0x5, 0xe, 0x8, 0x2, 0x8b, 0x8c, 0x7, 0x4, 0x2, 0x2, 0x8c, 
    0x8e, 0x5, 0xe, 0x8, 0x2, 0x8d, 0x8b, 0x3, 0x2, 0x2, 0x2, 0x8d, 0x8e, 
    0x3, 0x2, 0x2, 0x2, 0x8e, 0x8f, 0x3, 0x2, 0x2, 0x2, 0x8f, 0x90, 0x7, 
    0x3, 0x2, 0x2, 0x90, 0x9a, 0x3, 0x2, 0x2, 0x2, 0x91, 0x92, 0x7, 0x19, 
    0x2, 0x2, 0x92, 0x95, 0x5, 0xe, 0x8, 0x2, 0x93, 0x94, 0x7, 0x4, 0x2, 
    0x2, 0x94, 0x96, 0x5, 0xe, 0x8, 0x2, 0x95, 0x93, 0x3, 0x2, 0x2, 0x2, 
    0x95, 0x96, 0x3, 0x2, 0x2, 0x2, 0x96, 0x97, 0x3, 0x2, 0x2, 0x2, 0x97, 
    0x98, 0x7, 0x3, 0x2, 0x2, 0x98, 0x9a, 0x3, 0x2, 0x2, 0x2, 0x99, 0x89, 
    0x3, 0x2, 0x2, 0x2, 0x99, 0x91, 0x3, 0x2, 0x2, 0x2, 0x9a, 0x11, 0x3, 
    0x2, 0x2, 0x2, 0x9b, 0x9c, 0x9, 0x5, 0x2, 0x2, 0x9c, 0x13, 0x3, 0x2, 
    0x2, 0x2, 0x19, 0x17, 0x27, 0x2c, 0x2e, 0x38, 0x3b, 0x42, 0x4b, 0x55, 
    0x5a, 0x5d, 0x60, 0x65, 0x68, 0x6b, 0x70, 0x73, 0x79, 0x84, 0x86, 0x8d, 
    0x95, 0x99, 
  };

  atn::ATNDeserializer deserializer;
  _atn = deserializer.deserialize(_serializedATN);

  size_t count = _atn.getNumberOfDecisions();
  _decisionToDFA.reserve(count);
  for (size_t i = 0; i < count; i++) { 
    _decisionToDFA.emplace_back(_atn.getDecisionState(i), i);
  }
}

ExprParser::Initializer ExprParser::_init;
