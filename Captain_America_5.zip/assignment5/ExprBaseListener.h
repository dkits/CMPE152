
// Generated from Expr.g4 by ANTLR 4.7.1

#pragma once


#include "antlr4-runtime.h"
#include "ExprListener.h"


/**
 * This class provides an empty implementation of ExprListener,
 * which can be extended to create a listener which only needs to handle a subset
 * of the available methods.
 */
class  ExprBaseListener : public ExprListener {
public:

  virtual void enterProg(ExprParser::ProgContext * /*ctx*/) override { }
  virtual void exitProg(ExprParser::ProgContext * /*ctx*/) override { }

  virtual void enterStat(ExprParser::StatContext * /*ctx*/) override { }
  virtual void exitStat(ExprParser::StatContext * /*ctx*/) override { }

  virtual void enterIf_stat(ExprParser::If_statContext * /*ctx*/) override { }
  virtual void exitIf_stat(ExprParser::If_statContext * /*ctx*/) override { }

  virtual void enterWhile_stat(ExprParser::While_statContext * /*ctx*/) override { }
  virtual void exitWhile_stat(ExprParser::While_statContext * /*ctx*/) override { }

  virtual void enterFunction(ExprParser::FunctionContext * /*ctx*/) override { }
  virtual void exitFunction(ExprParser::FunctionContext * /*ctx*/) override { }

  virtual void enterFunc_call(ExprParser::Func_callContext * /*ctx*/) override { }
  virtual void exitFunc_call(ExprParser::Func_callContext * /*ctx*/) override { }

  virtual void enterExpr(ExprParser::ExprContext * /*ctx*/) override { }
  virtual void exitExpr(ExprParser::ExprContext * /*ctx*/) override { }

  virtual void enterVar_dec(ExprParser::Var_decContext * /*ctx*/) override { }
  virtual void exitVar_dec(ExprParser::Var_decContext * /*ctx*/) override { }

  virtual void enterFunc_synt(ExprParser::Func_syntContext * /*ctx*/) override { }
  virtual void exitFunc_synt(ExprParser::Func_syntContext * /*ctx*/) override { }


  virtual void enterEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void exitEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void visitTerminal(antlr4::tree::TerminalNode * /*node*/) override { }
  virtual void visitErrorNode(antlr4::tree::ErrorNode * /*node*/) override { }

};

