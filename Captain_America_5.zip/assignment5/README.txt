t.expr has our sample codes

there are 5 syntax diagrams
there are 4 parse trees

TokenStreamDump.txt has the token stream dump
and the textual parse tree