
#include "wci/intermediate/TypeSpec.h"
using namespace wci::intermediate;


// Generated from SimpleC.g4 by ANTLR 4.7.1


#include "SimpleCVisitor.h"

#include "SimpleCParser.h"


using namespace antlrcpp;
using namespace antlr4;

SimpleCParser::SimpleCParser(TokenStream *input) : Parser(input) {
  _interpreter = new atn::ParserATNSimulator(this, _atn, _decisionToDFA, _sharedContextCache);
}

SimpleCParser::~SimpleCParser() {
  delete _interpreter;
}

std::string SimpleCParser::getGrammarFileName() const {
  return "SimpleC.g4";
}

const std::vector<std::string>& SimpleCParser::getRuleNames() const {
  return _ruleNames;
}

dfa::Vocabulary& SimpleCParser::getVocabulary() const {
  return _vocabulary;
}


//----------------- ProgContext ------------------------------------------------------------------

SimpleCParser::ProgContext::ProgContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

SimpleCParser::HeaderContext* SimpleCParser::ProgContext::header() {
  return getRuleContext<SimpleCParser::HeaderContext>(0);
}

SimpleCParser::BlockContext* SimpleCParser::ProgContext::block() {
  return getRuleContext<SimpleCParser::BlockContext>(0);
}


size_t SimpleCParser::ProgContext::getRuleIndex() const {
  return SimpleCParser::RuleProg;
}

antlrcpp::Any SimpleCParser::ProgContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitProg(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::ProgContext* SimpleCParser::prog() {
  ProgContext *_localctx = _tracker.createInstance<ProgContext>(_ctx, getState());
  enterRule(_localctx, 0, SimpleCParser::RuleProg);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(22);
    header();
    setState(23);
    match(SimpleCParser::T__0);
    setState(24);
    block();
    setState(25);
    match(SimpleCParser::T__1);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- HeaderContext ------------------------------------------------------------------

SimpleCParser::HeaderContext::HeaderContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* SimpleCParser::HeaderContext::MAIN() {
  return getToken(SimpleCParser::MAIN, 0);
}


size_t SimpleCParser::HeaderContext::getRuleIndex() const {
  return SimpleCParser::RuleHeader;
}

antlrcpp::Any SimpleCParser::HeaderContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitHeader(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::HeaderContext* SimpleCParser::header() {
  HeaderContext *_localctx = _tracker.createInstance<HeaderContext>(_ctx, getState());
  enterRule(_localctx, 2, SimpleCParser::RuleHeader);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(27);
    match(SimpleCParser::MAIN);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- BlockContext ------------------------------------------------------------------

SimpleCParser::BlockContext::BlockContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<SimpleCParser::StatContext *> SimpleCParser::BlockContext::stat() {
  return getRuleContexts<SimpleCParser::StatContext>();
}

SimpleCParser::StatContext* SimpleCParser::BlockContext::stat(size_t i) {
  return getRuleContext<SimpleCParser::StatContext>(i);
}


size_t SimpleCParser::BlockContext::getRuleIndex() const {
  return SimpleCParser::RuleBlock;
}

antlrcpp::Any SimpleCParser::BlockContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitBlock(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::BlockContext* SimpleCParser::block() {
  BlockContext *_localctx = _tracker.createInstance<BlockContext>(_ctx, getState());
  enterRule(_localctx, 4, SimpleCParser::RuleBlock);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(30); 
    _errHandler->sync(this);
    _la = _input->LA(1);
    do {
      setState(29);
      stat();
      setState(32); 
      _errHandler->sync(this);
      _la = _input->LA(1);
    } while ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << SimpleCParser::T__0)
      | (1ULL << SimpleCParser::T__4)
      | (1ULL << SimpleCParser::T__5)
      | (1ULL << SimpleCParser::T__6)
      | (1ULL << SimpleCParser::T__7)
      | (1ULL << SimpleCParser::T__9)
      | (1ULL << SimpleCParser::T__19)
      | (1ULL << SimpleCParser::T__21)
      | (1ULL << SimpleCParser::T__23)
      | (1ULL << SimpleCParser::ID)
      | (1ULL << SimpleCParser::INT)
      | (1ULL << SimpleCParser::BOOL))) != 0));
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- StatContext ------------------------------------------------------------------

SimpleCParser::StatContext::StatContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t SimpleCParser::StatContext::getRuleIndex() const {
  return SimpleCParser::RuleStat;
}

void SimpleCParser::StatContext::copyFrom(StatContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- StatCallContext ------------------------------------------------------------------

SimpleCParser::Func_callContext* SimpleCParser::StatCallContext::func_call() {
  return getRuleContext<SimpleCParser::Func_callContext>(0);
}

SimpleCParser::StatCallContext::StatCallContext(StatContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::StatCallContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitStatCall(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StatIDContext ------------------------------------------------------------------

tree::TerminalNode* SimpleCParser::StatIDContext::ID() {
  return getToken(SimpleCParser::ID, 0);
}

SimpleCParser::ExprContext* SimpleCParser::StatIDContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}

SimpleCParser::StatIDContext::StatIDContext(StatContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::StatIDContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitStatID(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StatWhileContext ------------------------------------------------------------------

SimpleCParser::While_statContext* SimpleCParser::StatWhileContext::while_stat() {
  return getRuleContext<SimpleCParser::While_statContext>(0);
}

SimpleCParser::StatWhileContext::StatWhileContext(StatContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::StatWhileContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitStatWhile(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StatRetContext ------------------------------------------------------------------

SimpleCParser::ExprContext* SimpleCParser::StatRetContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}

SimpleCParser::StatRetContext::StatRetContext(StatContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::StatRetContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitStatRet(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StatVarContext ------------------------------------------------------------------

SimpleCParser::Var_decContext* SimpleCParser::StatVarContext::var_dec() {
  return getRuleContext<SimpleCParser::Var_decContext>(0);
}

SimpleCParser::StatVarContext::StatVarContext(StatContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::StatVarContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitStatVar(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StatExprContext ------------------------------------------------------------------

SimpleCParser::ExprContext* SimpleCParser::StatExprContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}

SimpleCParser::StatExprContext::StatExprContext(StatContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::StatExprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitStatExpr(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StatID_equalsContext ------------------------------------------------------------------

tree::TerminalNode* SimpleCParser::StatID_equalsContext::ID() {
  return getToken(SimpleCParser::ID, 0);
}

SimpleCParser::ExprContext* SimpleCParser::StatID_equalsContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}

std::vector<SimpleCParser::StatContext *> SimpleCParser::StatID_equalsContext::stat() {
  return getRuleContexts<SimpleCParser::StatContext>();
}

SimpleCParser::StatContext* SimpleCParser::StatID_equalsContext::stat(size_t i) {
  return getRuleContext<SimpleCParser::StatContext>(i);
}

SimpleCParser::StatID_equalsContext::StatID_equalsContext(StatContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::StatID_equalsContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitStatID_equals(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StatIfContext ------------------------------------------------------------------

SimpleCParser::If_statContext* SimpleCParser::StatIfContext::if_stat() {
  return getRuleContext<SimpleCParser::If_statContext>(0);
}

SimpleCParser::StatIfContext::StatIfContext(StatContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::StatIfContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitStatIf(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StatFuncContext ------------------------------------------------------------------

SimpleCParser::FunctionContext* SimpleCParser::StatFuncContext::function() {
  return getRuleContext<SimpleCParser::FunctionContext>(0);
}

SimpleCParser::StatFuncContext::StatFuncContext(StatContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::StatFuncContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitStatFunc(this);
  else
    return visitor->visitChildren(this);
}
SimpleCParser::StatContext* SimpleCParser::stat() {
  StatContext *_localctx = _tracker.createInstance<StatContext>(_ctx, getState());
  enterRule(_localctx, 6, SimpleCParser::RuleStat);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(68);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 5, _ctx)) {
    case 1: {
      _localctx = dynamic_cast<StatContext *>(_tracker.createInstance<SimpleCParser::StatExprContext>(_localctx));
      enterOuterAlt(_localctx, 1);
      setState(34);
      expr(0);
      setState(35);
      match(SimpleCParser::T__2);
      break;
    }

    case 2: {
      _localctx = dynamic_cast<StatContext *>(_tracker.createInstance<SimpleCParser::StatIDContext>(_localctx));
      enterOuterAlt(_localctx, 2);
      setState(37);
      match(SimpleCParser::ID);
      setState(38);
      match(SimpleCParser::T__3);
      setState(39);
      expr(0);
      setState(40);
      match(SimpleCParser::T__2);
      break;
    }

    case 3: {
      _localctx = dynamic_cast<StatContext *>(_tracker.createInstance<SimpleCParser::StatID_equalsContext>(_localctx));
      enterOuterAlt(_localctx, 3);
      setState(42);
      match(SimpleCParser::T__0);
      setState(48);
      _errHandler->sync(this);

      switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 1, _ctx)) {
      case 1: {
        setState(43);
        match(SimpleCParser::ID);
        setState(44);
        match(SimpleCParser::T__3);
        setState(45);
        expr(0);
        setState(46);
        match(SimpleCParser::T__2);
        break;
      }

      }
      setState(55);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if ((((_la & ~ 0x3fULL) == 0) &&
        ((1ULL << _la) & ((1ULL << SimpleCParser::T__0)
        | (1ULL << SimpleCParser::T__4)
        | (1ULL << SimpleCParser::T__5)
        | (1ULL << SimpleCParser::T__6)
        | (1ULL << SimpleCParser::T__7)
        | (1ULL << SimpleCParser::T__9)
        | (1ULL << SimpleCParser::T__19)
        | (1ULL << SimpleCParser::T__21)
        | (1ULL << SimpleCParser::T__23)
        | (1ULL << SimpleCParser::ID)
        | (1ULL << SimpleCParser::INT)
        | (1ULL << SimpleCParser::BOOL))) != 0)) {
        setState(51); 
        _errHandler->sync(this);
        _la = _input->LA(1);
        do {
          setState(50);
          stat();
          setState(53); 
          _errHandler->sync(this);
          _la = _input->LA(1);
        } while ((((_la & ~ 0x3fULL) == 0) &&
          ((1ULL << _la) & ((1ULL << SimpleCParser::T__0)
          | (1ULL << SimpleCParser::T__4)
          | (1ULL << SimpleCParser::T__5)
          | (1ULL << SimpleCParser::T__6)
          | (1ULL << SimpleCParser::T__7)
          | (1ULL << SimpleCParser::T__9)
          | (1ULL << SimpleCParser::T__19)
          | (1ULL << SimpleCParser::T__21)
          | (1ULL << SimpleCParser::T__23)
          | (1ULL << SimpleCParser::ID)
          | (1ULL << SimpleCParser::INT)
          | (1ULL << SimpleCParser::BOOL))) != 0));
      }
      setState(57);
      match(SimpleCParser::T__1);
      break;
    }

    case 4: {
      _localctx = dynamic_cast<StatContext *>(_tracker.createInstance<SimpleCParser::StatVarContext>(_localctx));
      enterOuterAlt(_localctx, 4);
      setState(58);
      var_dec();
      break;
    }

    case 5: {
      _localctx = dynamic_cast<StatContext *>(_tracker.createInstance<SimpleCParser::StatIfContext>(_localctx));
      enterOuterAlt(_localctx, 5);
      setState(59);
      if_stat();
      break;
    }

    case 6: {
      _localctx = dynamic_cast<StatContext *>(_tracker.createInstance<SimpleCParser::StatWhileContext>(_localctx));
      enterOuterAlt(_localctx, 6);
      setState(60);
      while_stat();
      break;
    }

    case 7: {
      _localctx = dynamic_cast<StatContext *>(_tracker.createInstance<SimpleCParser::StatFuncContext>(_localctx));
      enterOuterAlt(_localctx, 7);
      setState(61);
      function();
      break;
    }

    case 8: {
      _localctx = dynamic_cast<StatContext *>(_tracker.createInstance<SimpleCParser::StatCallContext>(_localctx));
      enterOuterAlt(_localctx, 8);
      setState(62);
      func_call();
      break;
    }

    case 9: {
      _localctx = dynamic_cast<StatContext *>(_tracker.createInstance<SimpleCParser::StatRetContext>(_localctx));
      enterOuterAlt(_localctx, 9);
      setState(63);
      match(SimpleCParser::T__4);
      setState(65);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if ((((_la & ~ 0x3fULL) == 0) &&
        ((1ULL << _la) & ((1ULL << SimpleCParser::T__19)
        | (1ULL << SimpleCParser::T__21)
        | (1ULL << SimpleCParser::ID)
        | (1ULL << SimpleCParser::INT)
        | (1ULL << SimpleCParser::BOOL))) != 0)) {
        setState(64);
        expr(0);
      }
      setState(67);
      match(SimpleCParser::T__2);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Var_decContext ------------------------------------------------------------------

SimpleCParser::Var_decContext::Var_decContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t SimpleCParser::Var_decContext::getRuleIndex() const {
  return SimpleCParser::RuleVar_dec;
}

void SimpleCParser::Var_decContext::copyFrom(Var_decContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- VarBoolContext ------------------------------------------------------------------

std::vector<SimpleCParser::ExprContext *> SimpleCParser::VarBoolContext::expr() {
  return getRuleContexts<SimpleCParser::ExprContext>();
}

SimpleCParser::ExprContext* SimpleCParser::VarBoolContext::expr(size_t i) {
  return getRuleContext<SimpleCParser::ExprContext>(i);
}

SimpleCParser::VarBoolContext::VarBoolContext(Var_decContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::VarBoolContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitVarBool(this);
  else
    return visitor->visitChildren(this);
}
//----------------- VarIntContext ------------------------------------------------------------------

std::vector<SimpleCParser::ExprContext *> SimpleCParser::VarIntContext::expr() {
  return getRuleContexts<SimpleCParser::ExprContext>();
}

SimpleCParser::ExprContext* SimpleCParser::VarIntContext::expr(size_t i) {
  return getRuleContext<SimpleCParser::ExprContext>(i);
}

SimpleCParser::VarIntContext::VarIntContext(Var_decContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::VarIntContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitVarInt(this);
  else
    return visitor->visitChildren(this);
}
SimpleCParser::Var_decContext* SimpleCParser::var_dec() {
  Var_decContext *_localctx = _tracker.createInstance<Var_decContext>(_ctx, getState());
  enterRule(_localctx, 8, SimpleCParser::RuleVar_dec);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(86);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case SimpleCParser::T__5: {
        _localctx = dynamic_cast<Var_decContext *>(_tracker.createInstance<SimpleCParser::VarIntContext>(_localctx));
        enterOuterAlt(_localctx, 1);
        setState(70);
        match(SimpleCParser::T__5);
        setState(71);
        expr(0);
        setState(74);
        _errHandler->sync(this);

        _la = _input->LA(1);
        if (_la == SimpleCParser::T__3) {
          setState(72);
          match(SimpleCParser::T__3);
          setState(73);
          expr(0);
        }
        setState(76);
        match(SimpleCParser::T__2);
        break;
      }

      case SimpleCParser::T__6: {
        _localctx = dynamic_cast<Var_decContext *>(_tracker.createInstance<SimpleCParser::VarBoolContext>(_localctx));
        enterOuterAlt(_localctx, 2);
        setState(78);
        match(SimpleCParser::T__6);
        setState(79);
        expr(0);
        setState(82);
        _errHandler->sync(this);

        _la = _input->LA(1);
        if (_la == SimpleCParser::T__3) {
          setState(80);
          match(SimpleCParser::T__3);
          setState(81);
          expr(0);
        }
        setState(84);
        match(SimpleCParser::T__2);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- If_statContext ------------------------------------------------------------------

SimpleCParser::If_statContext::If_statContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

SimpleCParser::ExprContext* SimpleCParser::If_statContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}

std::vector<SimpleCParser::StatContext *> SimpleCParser::If_statContext::stat() {
  return getRuleContexts<SimpleCParser::StatContext>();
}

SimpleCParser::StatContext* SimpleCParser::If_statContext::stat(size_t i) {
  return getRuleContext<SimpleCParser::StatContext>(i);
}


size_t SimpleCParser::If_statContext::getRuleIndex() const {
  return SimpleCParser::RuleIf_stat;
}

antlrcpp::Any SimpleCParser::If_statContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitIf_stat(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::If_statContext* SimpleCParser::if_stat() {
  If_statContext *_localctx = _tracker.createInstance<If_statContext>(_ctx, getState());
  enterRule(_localctx, 10, SimpleCParser::RuleIf_stat);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(88);
    match(SimpleCParser::T__7);
    setState(89);
    expr(0);
    setState(90);
    stat();
    setState(93);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 9, _ctx)) {
    case 1: {
      setState(91);
      match(SimpleCParser::T__8);
      setState(92);
      stat();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- While_statContext ------------------------------------------------------------------

SimpleCParser::While_statContext::While_statContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

SimpleCParser::ExprContext* SimpleCParser::While_statContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}

SimpleCParser::StatContext* SimpleCParser::While_statContext::stat() {
  return getRuleContext<SimpleCParser::StatContext>(0);
}


size_t SimpleCParser::While_statContext::getRuleIndex() const {
  return SimpleCParser::RuleWhile_stat;
}

antlrcpp::Any SimpleCParser::While_statContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitWhile_stat(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::While_statContext* SimpleCParser::while_stat() {
  While_statContext *_localctx = _tracker.createInstance<While_statContext>(_ctx, getState());
  enterRule(_localctx, 12, SimpleCParser::RuleWhile_stat);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(95);
    match(SimpleCParser::T__9);
    setState(96);
    expr(0);
    setState(97);
    stat();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- FunctionContext ------------------------------------------------------------------

SimpleCParser::FunctionContext::FunctionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

SimpleCParser::Func_syntContext* SimpleCParser::FunctionContext::func_synt() {
  return getRuleContext<SimpleCParser::Func_syntContext>(0);
}

tree::TerminalNode* SimpleCParser::FunctionContext::ID() {
  return getToken(SimpleCParser::ID, 0);
}

SimpleCParser::StatContext* SimpleCParser::FunctionContext::stat() {
  return getRuleContext<SimpleCParser::StatContext>(0);
}

SimpleCParser::ExprContext* SimpleCParser::FunctionContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}


size_t SimpleCParser::FunctionContext::getRuleIndex() const {
  return SimpleCParser::RuleFunction;
}

antlrcpp::Any SimpleCParser::FunctionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitFunction(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::FunctionContext* SimpleCParser::function() {
  FunctionContext *_localctx = _tracker.createInstance<FunctionContext>(_ctx, getState());
  enterRule(_localctx, 14, SimpleCParser::RuleFunction);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(99);
    func_synt();
    setState(100);
    match(SimpleCParser::ID);
    setState(102);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 10, _ctx)) {
    case 1: {
      setState(101);
      expr(0);
      break;
    }

    }
    setState(104);
    stat();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Func_callContext ------------------------------------------------------------------

SimpleCParser::Func_callContext::Func_callContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* SimpleCParser::Func_callContext::ID() {
  return getToken(SimpleCParser::ID, 0);
}

SimpleCParser::ExprContext* SimpleCParser::Func_callContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}


size_t SimpleCParser::Func_callContext::getRuleIndex() const {
  return SimpleCParser::RuleFunc_call;
}

antlrcpp::Any SimpleCParser::Func_callContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitFunc_call(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::Func_callContext* SimpleCParser::func_call() {
  Func_callContext *_localctx = _tracker.createInstance<Func_callContext>(_ctx, getState());
  enterRule(_localctx, 16, SimpleCParser::RuleFunc_call);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(106);
    match(SimpleCParser::ID);
    setState(107);
    expr(0);
    setState(108);
    match(SimpleCParser::T__2);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExprContext ------------------------------------------------------------------

SimpleCParser::ExprContext::ExprContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t SimpleCParser::ExprContext::getRuleIndex() const {
  return SimpleCParser::RuleExpr;
}

void SimpleCParser::ExprContext::copyFrom(ExprContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
  this->type = ctx->type;
}

//----------------- ExprMultDivContext ------------------------------------------------------------------

std::vector<SimpleCParser::ExprContext *> SimpleCParser::ExprMultDivContext::expr() {
  return getRuleContexts<SimpleCParser::ExprContext>();
}

SimpleCParser::ExprContext* SimpleCParser::ExprMultDivContext::expr(size_t i) {
  return getRuleContext<SimpleCParser::ExprContext>(i);
}

SimpleCParser::ExprMultDivContext::ExprMultDivContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::ExprMultDivContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitExprMultDiv(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ExprFuncIntContext ------------------------------------------------------------------

tree::TerminalNode* SimpleCParser::ExprFuncIntContext::INT() {
  return getToken(SimpleCParser::INT, 0);
}

SimpleCParser::ExprContext* SimpleCParser::ExprFuncIntContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}

SimpleCParser::ExprFuncIntContext::ExprFuncIntContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::ExprFuncIntContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitExprFuncInt(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ExprCompContext ------------------------------------------------------------------

std::vector<SimpleCParser::ExprContext *> SimpleCParser::ExprCompContext::expr() {
  return getRuleContexts<SimpleCParser::ExprContext>();
}

SimpleCParser::ExprContext* SimpleCParser::ExprCompContext::expr(size_t i) {
  return getRuleContext<SimpleCParser::ExprContext>(i);
}

SimpleCParser::ExprCompContext::ExprCompContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::ExprCompContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitExprComp(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ExprAddSubContext ------------------------------------------------------------------

std::vector<SimpleCParser::ExprContext *> SimpleCParser::ExprAddSubContext::expr() {
  return getRuleContexts<SimpleCParser::ExprContext>();
}

SimpleCParser::ExprContext* SimpleCParser::ExprAddSubContext::expr(size_t i) {
  return getRuleContext<SimpleCParser::ExprContext>(i);
}

SimpleCParser::ExprAddSubContext::ExprAddSubContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::ExprAddSubContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitExprAddSub(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ExprParaContext ------------------------------------------------------------------

SimpleCParser::ExprContext* SimpleCParser::ExprParaContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}

SimpleCParser::ExprParaContext::ExprParaContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::ExprParaContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitExprPara(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ExprFuncIDContext ------------------------------------------------------------------

tree::TerminalNode* SimpleCParser::ExprFuncIDContext::ID() {
  return getToken(SimpleCParser::ID, 0);
}

SimpleCParser::ExprContext* SimpleCParser::ExprFuncIDContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}

SimpleCParser::ExprFuncIDContext::ExprFuncIDContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::ExprFuncIDContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitExprFuncID(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ExprFuncBoolContext ------------------------------------------------------------------

tree::TerminalNode* SimpleCParser::ExprFuncBoolContext::BOOL() {
  return getToken(SimpleCParser::BOOL, 0);
}

SimpleCParser::ExprContext* SimpleCParser::ExprFuncBoolContext::expr() {
  return getRuleContext<SimpleCParser::ExprContext>(0);
}

SimpleCParser::ExprFuncBoolContext::ExprFuncBoolContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::ExprFuncBoolContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitExprFuncBool(this);
  else
    return visitor->visitChildren(this);
}

SimpleCParser::ExprContext* SimpleCParser::expr() {
   return expr(0);
}

SimpleCParser::ExprContext* SimpleCParser::expr(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  SimpleCParser::ExprContext *_localctx = _tracker.createInstance<ExprContext>(_ctx, parentState);
  SimpleCParser::ExprContext *previousContext = _localctx;
  size_t startState = 18;
  enterRecursionRule(_localctx, 18, SimpleCParser::RuleExpr, precedence);

    size_t _la = 0;

  auto onExit = finally([=] {
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(148);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 20, _ctx)) {
    case 1: {
      _localctx = _tracker.createInstance<ExprFuncIntContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;

      setState(112);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == SimpleCParser::T__19) {
        setState(111);
        match(SimpleCParser::T__19);
      }
      setState(114);
      match(SimpleCParser::INT);
      setState(120);
      _errHandler->sync(this);

      switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 13, _ctx)) {
      case 1: {
        setState(115);
        match(SimpleCParser::T__20);
        setState(117);
        _errHandler->sync(this);

        switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 12, _ctx)) {
        case 1: {
          setState(116);
          match(SimpleCParser::T__19);
          break;
        }

        }
        setState(119);
        expr(0);
        break;
      }

      }
      break;
    }

    case 2: {
      _localctx = _tracker.createInstance<ExprFuncIDContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;
      setState(123);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == SimpleCParser::T__19) {
        setState(122);
        match(SimpleCParser::T__19);
      }
      setState(125);
      match(SimpleCParser::ID);
      setState(131);
      _errHandler->sync(this);

      switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 16, _ctx)) {
      case 1: {
        setState(126);
        match(SimpleCParser::T__20);
        setState(128);
        _errHandler->sync(this);

        switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 15, _ctx)) {
        case 1: {
          setState(127);
          match(SimpleCParser::T__19);
          break;
        }

        }
        setState(130);
        expr(0);
        break;
      }

      }
      break;
    }

    case 3: {
      _localctx = _tracker.createInstance<ExprFuncBoolContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;
      setState(134);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == SimpleCParser::T__19) {
        setState(133);
        match(SimpleCParser::T__19);
      }
      setState(136);
      match(SimpleCParser::BOOL);
      setState(142);
      _errHandler->sync(this);

      switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 19, _ctx)) {
      case 1: {
        setState(137);
        match(SimpleCParser::T__20);
        setState(139);
        _errHandler->sync(this);

        switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 18, _ctx)) {
        case 1: {
          setState(138);
          match(SimpleCParser::T__19);
          break;
        }

        }
        setState(141);
        expr(0);
        break;
      }

      }
      break;
    }

    case 4: {
      _localctx = _tracker.createInstance<ExprParaContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;
      setState(144);
      match(SimpleCParser::T__21);
      setState(145);
      expr(0);
      setState(146);
      match(SimpleCParser::T__22);
      break;
    }

    }
    _ctx->stop = _input->LT(-1);
    setState(161);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 22, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        setState(159);
        _errHandler->sync(this);
        switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 21, _ctx)) {
        case 1: {
          auto newContext = _tracker.createInstance<ExprMultDivContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(150);

          if (!(precpred(_ctx, 7))) throw FailedPredicateException(this, "precpred(_ctx, 7)");
          setState(151);
          _la = _input->LA(1);
          if (!(_la == SimpleCParser::T__10

          || _la == SimpleCParser::T__11)) {
          _errHandler->recoverInline(this);
          }
          else {
            _errHandler->reportMatch(this);
            consume();
          }
          setState(152);
          expr(8);
          break;
        }

        case 2: {
          auto newContext = _tracker.createInstance<ExprAddSubContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(153);

          if (!(precpred(_ctx, 6))) throw FailedPredicateException(this, "precpred(_ctx, 6)");
          setState(154);
          _la = _input->LA(1);
          if (!(_la == SimpleCParser::T__12

          || _la == SimpleCParser::T__13)) {
          _errHandler->recoverInline(this);
          }
          else {
            _errHandler->reportMatch(this);
            consume();
          }
          setState(155);
          expr(7);
          break;
        }

        case 3: {
          auto newContext = _tracker.createInstance<ExprCompContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(156);

          if (!(precpred(_ctx, 5))) throw FailedPredicateException(this, "precpred(_ctx, 5)");
          setState(157);
          _la = _input->LA(1);
          if (!((((_la & ~ 0x3fULL) == 0) &&
            ((1ULL << _la) & ((1ULL << SimpleCParser::T__14)
            | (1ULL << SimpleCParser::T__15)
            | (1ULL << SimpleCParser::T__16)
            | (1ULL << SimpleCParser::T__17)
            | (1ULL << SimpleCParser::T__18))) != 0))) {
          _errHandler->recoverInline(this);
          }
          else {
            _errHandler->reportMatch(this);
            consume();
          }
          setState(158);
          expr(6);
          break;
        }

        } 
      }
      setState(163);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 22, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

//----------------- Func_syntContext ------------------------------------------------------------------

SimpleCParser::Func_syntContext::Func_syntContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t SimpleCParser::Func_syntContext::getRuleIndex() const {
  return SimpleCParser::RuleFunc_synt;
}

void SimpleCParser::Func_syntContext::copyFrom(Func_syntContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- FuncIntContext ------------------------------------------------------------------

SimpleCParser::FuncIntContext::FuncIntContext(Func_syntContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::FuncIntContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitFuncInt(this);
  else
    return visitor->visitChildren(this);
}
//----------------- FuncBoolContext ------------------------------------------------------------------

SimpleCParser::FuncBoolContext::FuncBoolContext(Func_syntContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::FuncBoolContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitFuncBool(this);
  else
    return visitor->visitChildren(this);
}
//----------------- FuncVoidContext ------------------------------------------------------------------

SimpleCParser::FuncVoidContext::FuncVoidContext(Func_syntContext *ctx) { copyFrom(ctx); }

antlrcpp::Any SimpleCParser::FuncVoidContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<SimpleCVisitor*>(visitor))
    return parserVisitor->visitFuncVoid(this);
  else
    return visitor->visitChildren(this);
}
SimpleCParser::Func_syntContext* SimpleCParser::func_synt() {
  Func_syntContext *_localctx = _tracker.createInstance<Func_syntContext>(_ctx, getState());
  enterRule(_localctx, 20, SimpleCParser::RuleFunc_synt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(167);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case SimpleCParser::T__23: {
        _localctx = dynamic_cast<Func_syntContext *>(_tracker.createInstance<SimpleCParser::FuncVoidContext>(_localctx));
        enterOuterAlt(_localctx, 1);
        setState(164);
        match(SimpleCParser::T__23);
        break;
      }

      case SimpleCParser::T__5: {
        _localctx = dynamic_cast<Func_syntContext *>(_tracker.createInstance<SimpleCParser::FuncIntContext>(_localctx));
        enterOuterAlt(_localctx, 2);
        setState(165);
        match(SimpleCParser::T__5);
        break;
      }

      case SimpleCParser::T__6: {
        _localctx = dynamic_cast<Func_syntContext *>(_tracker.createInstance<SimpleCParser::FuncBoolContext>(_localctx));
        enterOuterAlt(_localctx, 3);
        setState(166);
        match(SimpleCParser::T__6);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

bool SimpleCParser::sempred(RuleContext *context, size_t ruleIndex, size_t predicateIndex) {
  switch (ruleIndex) {
    case 9: return exprSempred(dynamic_cast<ExprContext *>(context), predicateIndex);

  default:
    break;
  }
  return true;
}

bool SimpleCParser::exprSempred(ExprContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 0: return precpred(_ctx, 7);
    case 1: return precpred(_ctx, 6);
    case 2: return precpred(_ctx, 5);

  default:
    break;
  }
  return true;
}

// Static vars and initialization.
std::vector<dfa::DFA> SimpleCParser::_decisionToDFA;
atn::PredictionContextCache SimpleCParser::_sharedContextCache;

// We own the ATN which in turn owns the ATN states.
atn::ATN SimpleCParser::_atn;
std::vector<uint16_t> SimpleCParser::_serializedATN;

std::vector<std::string> SimpleCParser::_ruleNames = {
  "prog", "header", "block", "stat", "var_dec", "if_stat", "while_stat", 
  "function", "func_call", "expr", "func_synt"
};

std::vector<std::string> SimpleCParser::_literalNames = {
  "", "'{'", "'}'", "';'", "'='", "'return'", "'int'", "'bool'", "'if'", 
  "'else'", "'while'", "'*'", "'/'", "'+'", "'-'", "'=='", "'>='", "'<='", 
  "'>'", "'<'", "'#'", "','", "'('", "')'", "'void'", "'main'"
};

std::vector<std::string> SimpleCParser::_symbolicNames = {
  "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", 
  "", "", "", "", "", "", "", "MAIN", "ID", "INT", "BOOL", "WS"
};

dfa::Vocabulary SimpleCParser::_vocabulary(_literalNames, _symbolicNames);

std::vector<std::string> SimpleCParser::_tokenNames;

SimpleCParser::Initializer::Initializer() {
	for (size_t i = 0; i < _symbolicNames.size(); ++i) {
		std::string name = _vocabulary.getLiteralName(i);
		if (name.empty()) {
			name = _vocabulary.getSymbolicName(i);
		}

		if (name.empty()) {
			_tokenNames.push_back("<INVALID>");
		} else {
      _tokenNames.push_back(name);
    }
	}

  _serializedATN = {
    0x3, 0x608b, 0xa72a, 0x8133, 0xb9ed, 0x417c, 0x3be7, 0x7786, 0x5964, 
    0x3, 0x1f, 0xac, 0x4, 0x2, 0x9, 0x2, 0x4, 0x3, 0x9, 0x3, 0x4, 0x4, 0x9, 
    0x4, 0x4, 0x5, 0x9, 0x5, 0x4, 0x6, 0x9, 0x6, 0x4, 0x7, 0x9, 0x7, 0x4, 
    0x8, 0x9, 0x8, 0x4, 0x9, 0x9, 0x9, 0x4, 0xa, 0x9, 0xa, 0x4, 0xb, 0x9, 
    0xb, 0x4, 0xc, 0x9, 0xc, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 0x3, 
    0x2, 0x3, 0x3, 0x3, 0x3, 0x3, 0x4, 0x6, 0x4, 0x21, 0xa, 0x4, 0xd, 0x4, 
    0xe, 0x4, 0x22, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 
    0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 
    0x5, 0x3, 0x5, 0x5, 0x5, 0x33, 0xa, 0x5, 0x3, 0x5, 0x6, 0x5, 0x36, 0xa, 
    0x5, 0xd, 0x5, 0xe, 0x5, 0x37, 0x5, 0x5, 0x3a, 0xa, 0x5, 0x3, 0x5, 0x3, 
    0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x5, 
    0x5, 0x44, 0xa, 0x5, 0x3, 0x5, 0x5, 0x5, 0x47, 0xa, 0x5, 0x3, 0x6, 0x3, 
    0x6, 0x3, 0x6, 0x3, 0x6, 0x5, 0x6, 0x4d, 0xa, 0x6, 0x3, 0x6, 0x3, 0x6, 
    0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 0x5, 0x6, 0x55, 0xa, 0x6, 0x3, 
    0x6, 0x3, 0x6, 0x5, 0x6, 0x59, 0xa, 0x6, 0x3, 0x7, 0x3, 0x7, 0x3, 0x7, 
    0x3, 0x7, 0x3, 0x7, 0x5, 0x7, 0x60, 0xa, 0x7, 0x3, 0x8, 0x3, 0x8, 0x3, 
    0x8, 0x3, 0x8, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x5, 0x9, 0x69, 0xa, 0x9, 
    0x3, 0x9, 0x3, 0x9, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xb, 
    0x3, 0xb, 0x5, 0xb, 0x73, 0xa, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x5, 
    0xb, 0x78, 0xa, 0xb, 0x3, 0xb, 0x5, 0xb, 0x7b, 0xa, 0xb, 0x3, 0xb, 0x5, 
    0xb, 0x7e, 0xa, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x5, 0xb, 0x83, 0xa, 
    0xb, 0x3, 0xb, 0x5, 0xb, 0x86, 0xa, 0xb, 0x3, 0xb, 0x5, 0xb, 0x89, 0xa, 
    0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x5, 0xb, 0x8e, 0xa, 0xb, 0x3, 0xb, 
    0x5, 0xb, 0x91, 0xa, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x5, 
    0xb, 0x97, 0xa, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 
    0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x7, 0xb, 0xa2, 0xa, 0xb, 0xc, 
    0xb, 0xe, 0xb, 0xa5, 0xb, 0xb, 0x3, 0xc, 0x3, 0xc, 0x3, 0xc, 0x5, 0xc, 
    0xaa, 0xa, 0xc, 0x3, 0xc, 0x2, 0x3, 0x14, 0xd, 0x2, 0x4, 0x6, 0x8, 0xa, 
    0xc, 0xe, 0x10, 0x12, 0x14, 0x16, 0x2, 0x5, 0x3, 0x2, 0xd, 0xe, 0x3, 
    0x2, 0xf, 0x10, 0x3, 0x2, 0x11, 0x15, 0x2, 0xc3, 0x2, 0x18, 0x3, 0x2, 
    0x2, 0x2, 0x4, 0x1d, 0x3, 0x2, 0x2, 0x2, 0x6, 0x20, 0x3, 0x2, 0x2, 0x2, 
    0x8, 0x46, 0x3, 0x2, 0x2, 0x2, 0xa, 0x58, 0x3, 0x2, 0x2, 0x2, 0xc, 0x5a, 
    0x3, 0x2, 0x2, 0x2, 0xe, 0x61, 0x3, 0x2, 0x2, 0x2, 0x10, 0x65, 0x3, 
    0x2, 0x2, 0x2, 0x12, 0x6c, 0x3, 0x2, 0x2, 0x2, 0x14, 0x96, 0x3, 0x2, 
    0x2, 0x2, 0x16, 0xa9, 0x3, 0x2, 0x2, 0x2, 0x18, 0x19, 0x5, 0x4, 0x3, 
    0x2, 0x19, 0x1a, 0x7, 0x3, 0x2, 0x2, 0x1a, 0x1b, 0x5, 0x6, 0x4, 0x2, 
    0x1b, 0x1c, 0x7, 0x4, 0x2, 0x2, 0x1c, 0x3, 0x3, 0x2, 0x2, 0x2, 0x1d, 
    0x1e, 0x7, 0x1b, 0x2, 0x2, 0x1e, 0x5, 0x3, 0x2, 0x2, 0x2, 0x1f, 0x21, 
    0x5, 0x8, 0x5, 0x2, 0x20, 0x1f, 0x3, 0x2, 0x2, 0x2, 0x21, 0x22, 0x3, 
    0x2, 0x2, 0x2, 0x22, 0x20, 0x3, 0x2, 0x2, 0x2, 0x22, 0x23, 0x3, 0x2, 
    0x2, 0x2, 0x23, 0x7, 0x3, 0x2, 0x2, 0x2, 0x24, 0x25, 0x5, 0x14, 0xb, 
    0x2, 0x25, 0x26, 0x7, 0x5, 0x2, 0x2, 0x26, 0x47, 0x3, 0x2, 0x2, 0x2, 
    0x27, 0x28, 0x7, 0x1c, 0x2, 0x2, 0x28, 0x29, 0x7, 0x6, 0x2, 0x2, 0x29, 
    0x2a, 0x5, 0x14, 0xb, 0x2, 0x2a, 0x2b, 0x7, 0x5, 0x2, 0x2, 0x2b, 0x47, 
    0x3, 0x2, 0x2, 0x2, 0x2c, 0x32, 0x7, 0x3, 0x2, 0x2, 0x2d, 0x2e, 0x7, 
    0x1c, 0x2, 0x2, 0x2e, 0x2f, 0x7, 0x6, 0x2, 0x2, 0x2f, 0x30, 0x5, 0x14, 
    0xb, 0x2, 0x30, 0x31, 0x7, 0x5, 0x2, 0x2, 0x31, 0x33, 0x3, 0x2, 0x2, 
    0x2, 0x32, 0x2d, 0x3, 0x2, 0x2, 0x2, 0x32, 0x33, 0x3, 0x2, 0x2, 0x2, 
    0x33, 0x39, 0x3, 0x2, 0x2, 0x2, 0x34, 0x36, 0x5, 0x8, 0x5, 0x2, 0x35, 
    0x34, 0x3, 0x2, 0x2, 0x2, 0x36, 0x37, 0x3, 0x2, 0x2, 0x2, 0x37, 0x35, 
    0x3, 0x2, 0x2, 0x2, 0x37, 0x38, 0x3, 0x2, 0x2, 0x2, 0x38, 0x3a, 0x3, 
    0x2, 0x2, 0x2, 0x39, 0x35, 0x3, 0x2, 0x2, 0x2, 0x39, 0x3a, 0x3, 0x2, 
    0x2, 0x2, 0x3a, 0x3b, 0x3, 0x2, 0x2, 0x2, 0x3b, 0x47, 0x7, 0x4, 0x2, 
    0x2, 0x3c, 0x47, 0x5, 0xa, 0x6, 0x2, 0x3d, 0x47, 0x5, 0xc, 0x7, 0x2, 
    0x3e, 0x47, 0x5, 0xe, 0x8, 0x2, 0x3f, 0x47, 0x5, 0x10, 0x9, 0x2, 0x40, 
    0x47, 0x5, 0x12, 0xa, 0x2, 0x41, 0x43, 0x7, 0x7, 0x2, 0x2, 0x42, 0x44, 
    0x5, 0x14, 0xb, 0x2, 0x43, 0x42, 0x3, 0x2, 0x2, 0x2, 0x43, 0x44, 0x3, 
    0x2, 0x2, 0x2, 0x44, 0x45, 0x3, 0x2, 0x2, 0x2, 0x45, 0x47, 0x7, 0x5, 
    0x2, 0x2, 0x46, 0x24, 0x3, 0x2, 0x2, 0x2, 0x46, 0x27, 0x3, 0x2, 0x2, 
    0x2, 0x46, 0x2c, 0x3, 0x2, 0x2, 0x2, 0x46, 0x3c, 0x3, 0x2, 0x2, 0x2, 
    0x46, 0x3d, 0x3, 0x2, 0x2, 0x2, 0x46, 0x3e, 0x3, 0x2, 0x2, 0x2, 0x46, 
    0x3f, 0x3, 0x2, 0x2, 0x2, 0x46, 0x40, 0x3, 0x2, 0x2, 0x2, 0x46, 0x41, 
    0x3, 0x2, 0x2, 0x2, 0x47, 0x9, 0x3, 0x2, 0x2, 0x2, 0x48, 0x49, 0x7, 
    0x8, 0x2, 0x2, 0x49, 0x4c, 0x5, 0x14, 0xb, 0x2, 0x4a, 0x4b, 0x7, 0x6, 
    0x2, 0x2, 0x4b, 0x4d, 0x5, 0x14, 0xb, 0x2, 0x4c, 0x4a, 0x3, 0x2, 0x2, 
    0x2, 0x4c, 0x4d, 0x3, 0x2, 0x2, 0x2, 0x4d, 0x4e, 0x3, 0x2, 0x2, 0x2, 
    0x4e, 0x4f, 0x7, 0x5, 0x2, 0x2, 0x4f, 0x59, 0x3, 0x2, 0x2, 0x2, 0x50, 
    0x51, 0x7, 0x9, 0x2, 0x2, 0x51, 0x54, 0x5, 0x14, 0xb, 0x2, 0x52, 0x53, 
    0x7, 0x6, 0x2, 0x2, 0x53, 0x55, 0x5, 0x14, 0xb, 0x2, 0x54, 0x52, 0x3, 
    0x2, 0x2, 0x2, 0x54, 0x55, 0x3, 0x2, 0x2, 0x2, 0x55, 0x56, 0x3, 0x2, 
    0x2, 0x2, 0x56, 0x57, 0x7, 0x5, 0x2, 0x2, 0x57, 0x59, 0x3, 0x2, 0x2, 
    0x2, 0x58, 0x48, 0x3, 0x2, 0x2, 0x2, 0x58, 0x50, 0x3, 0x2, 0x2, 0x2, 
    0x59, 0xb, 0x3, 0x2, 0x2, 0x2, 0x5a, 0x5b, 0x7, 0xa, 0x2, 0x2, 0x5b, 
    0x5c, 0x5, 0x14, 0xb, 0x2, 0x5c, 0x5f, 0x5, 0x8, 0x5, 0x2, 0x5d, 0x5e, 
    0x7, 0xb, 0x2, 0x2, 0x5e, 0x60, 0x5, 0x8, 0x5, 0x2, 0x5f, 0x5d, 0x3, 
    0x2, 0x2, 0x2, 0x5f, 0x60, 0x3, 0x2, 0x2, 0x2, 0x60, 0xd, 0x3, 0x2, 
    0x2, 0x2, 0x61, 0x62, 0x7, 0xc, 0x2, 0x2, 0x62, 0x63, 0x5, 0x14, 0xb, 
    0x2, 0x63, 0x64, 0x5, 0x8, 0x5, 0x2, 0x64, 0xf, 0x3, 0x2, 0x2, 0x2, 
    0x65, 0x66, 0x5, 0x16, 0xc, 0x2, 0x66, 0x68, 0x7, 0x1c, 0x2, 0x2, 0x67, 
    0x69, 0x5, 0x14, 0xb, 0x2, 0x68, 0x67, 0x3, 0x2, 0x2, 0x2, 0x68, 0x69, 
    0x3, 0x2, 0x2, 0x2, 0x69, 0x6a, 0x3, 0x2, 0x2, 0x2, 0x6a, 0x6b, 0x5, 
    0x8, 0x5, 0x2, 0x6b, 0x11, 0x3, 0x2, 0x2, 0x2, 0x6c, 0x6d, 0x7, 0x1c, 
    0x2, 0x2, 0x6d, 0x6e, 0x5, 0x14, 0xb, 0x2, 0x6e, 0x6f, 0x7, 0x5, 0x2, 
    0x2, 0x6f, 0x13, 0x3, 0x2, 0x2, 0x2, 0x70, 0x72, 0x8, 0xb, 0x1, 0x2, 
    0x71, 0x73, 0x7, 0x16, 0x2, 0x2, 0x72, 0x71, 0x3, 0x2, 0x2, 0x2, 0x72, 
    0x73, 0x3, 0x2, 0x2, 0x2, 0x73, 0x74, 0x3, 0x2, 0x2, 0x2, 0x74, 0x7a, 
    0x7, 0x1d, 0x2, 0x2, 0x75, 0x77, 0x7, 0x17, 0x2, 0x2, 0x76, 0x78, 0x7, 
    0x16, 0x2, 0x2, 0x77, 0x76, 0x3, 0x2, 0x2, 0x2, 0x77, 0x78, 0x3, 0x2, 
    0x2, 0x2, 0x78, 0x79, 0x3, 0x2, 0x2, 0x2, 0x79, 0x7b, 0x5, 0x14, 0xb, 
    0x2, 0x7a, 0x75, 0x3, 0x2, 0x2, 0x2, 0x7a, 0x7b, 0x3, 0x2, 0x2, 0x2, 
    0x7b, 0x97, 0x3, 0x2, 0x2, 0x2, 0x7c, 0x7e, 0x7, 0x16, 0x2, 0x2, 0x7d, 
    0x7c, 0x3, 0x2, 0x2, 0x2, 0x7d, 0x7e, 0x3, 0x2, 0x2, 0x2, 0x7e, 0x7f, 
    0x3, 0x2, 0x2, 0x2, 0x7f, 0x85, 0x7, 0x1c, 0x2, 0x2, 0x80, 0x82, 0x7, 
    0x17, 0x2, 0x2, 0x81, 0x83, 0x7, 0x16, 0x2, 0x2, 0x82, 0x81, 0x3, 0x2, 
    0x2, 0x2, 0x82, 0x83, 0x3, 0x2, 0x2, 0x2, 0x83, 0x84, 0x3, 0x2, 0x2, 
    0x2, 0x84, 0x86, 0x5, 0x14, 0xb, 0x2, 0x85, 0x80, 0x3, 0x2, 0x2, 0x2, 
    0x85, 0x86, 0x3, 0x2, 0x2, 0x2, 0x86, 0x97, 0x3, 0x2, 0x2, 0x2, 0x87, 
    0x89, 0x7, 0x16, 0x2, 0x2, 0x88, 0x87, 0x3, 0x2, 0x2, 0x2, 0x88, 0x89, 
    0x3, 0x2, 0x2, 0x2, 0x89, 0x8a, 0x3, 0x2, 0x2, 0x2, 0x8a, 0x90, 0x7, 
    0x1e, 0x2, 0x2, 0x8b, 0x8d, 0x7, 0x17, 0x2, 0x2, 0x8c, 0x8e, 0x7, 0x16, 
    0x2, 0x2, 0x8d, 0x8c, 0x3, 0x2, 0x2, 0x2, 0x8d, 0x8e, 0x3, 0x2, 0x2, 
    0x2, 0x8e, 0x8f, 0x3, 0x2, 0x2, 0x2, 0x8f, 0x91, 0x5, 0x14, 0xb, 0x2, 
    0x90, 0x8b, 0x3, 0x2, 0x2, 0x2, 0x90, 0x91, 0x3, 0x2, 0x2, 0x2, 0x91, 
    0x97, 0x3, 0x2, 0x2, 0x2, 0x92, 0x93, 0x7, 0x18, 0x2, 0x2, 0x93, 0x94, 
    0x5, 0x14, 0xb, 0x2, 0x94, 0x95, 0x7, 0x19, 0x2, 0x2, 0x95, 0x97, 0x3, 
    0x2, 0x2, 0x2, 0x96, 0x70, 0x3, 0x2, 0x2, 0x2, 0x96, 0x7d, 0x3, 0x2, 
    0x2, 0x2, 0x96, 0x88, 0x3, 0x2, 0x2, 0x2, 0x96, 0x92, 0x3, 0x2, 0x2, 
    0x2, 0x97, 0xa3, 0x3, 0x2, 0x2, 0x2, 0x98, 0x99, 0xc, 0x9, 0x2, 0x2, 
    0x99, 0x9a, 0x9, 0x2, 0x2, 0x2, 0x9a, 0xa2, 0x5, 0x14, 0xb, 0xa, 0x9b, 
    0x9c, 0xc, 0x8, 0x2, 0x2, 0x9c, 0x9d, 0x9, 0x3, 0x2, 0x2, 0x9d, 0xa2, 
    0x5, 0x14, 0xb, 0x9, 0x9e, 0x9f, 0xc, 0x7, 0x2, 0x2, 0x9f, 0xa0, 0x9, 
    0x4, 0x2, 0x2, 0xa0, 0xa2, 0x5, 0x14, 0xb, 0x8, 0xa1, 0x98, 0x3, 0x2, 
    0x2, 0x2, 0xa1, 0x9b, 0x3, 0x2, 0x2, 0x2, 0xa1, 0x9e, 0x3, 0x2, 0x2, 
    0x2, 0xa2, 0xa5, 0x3, 0x2, 0x2, 0x2, 0xa3, 0xa1, 0x3, 0x2, 0x2, 0x2, 
    0xa3, 0xa4, 0x3, 0x2, 0x2, 0x2, 0xa4, 0x15, 0x3, 0x2, 0x2, 0x2, 0xa5, 
    0xa3, 0x3, 0x2, 0x2, 0x2, 0xa6, 0xaa, 0x7, 0x1a, 0x2, 0x2, 0xa7, 0xaa, 
    0x7, 0x8, 0x2, 0x2, 0xa8, 0xaa, 0x7, 0x9, 0x2, 0x2, 0xa9, 0xa6, 0x3, 
    0x2, 0x2, 0x2, 0xa9, 0xa7, 0x3, 0x2, 0x2, 0x2, 0xa9, 0xa8, 0x3, 0x2, 
    0x2, 0x2, 0xaa, 0x17, 0x3, 0x2, 0x2, 0x2, 0x1a, 0x22, 0x32, 0x37, 0x39, 
    0x43, 0x46, 0x4c, 0x54, 0x58, 0x5f, 0x68, 0x72, 0x77, 0x7a, 0x7d, 0x82, 
    0x85, 0x88, 0x8d, 0x90, 0x96, 0xa1, 0xa3, 0xa9, 
  };

  atn::ATNDeserializer deserializer;
  _atn = deserializer.deserialize(_serializedATN);

  size_t count = _atn.getNumberOfDecisions();
  _decisionToDFA.reserve(count);
  for (size_t i = 0; i < count; i++) { 
    _decisionToDFA.emplace_back(_atn.getDecisionState(i), i);
  }
}

SimpleCParser::Initializer SimpleCParser::_init;
