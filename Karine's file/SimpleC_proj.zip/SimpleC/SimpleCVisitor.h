
#include "wci/intermediate/TypeSpec.h"
using namespace wci::intermediate;


// Generated from SimpleC.g4 by ANTLR 4.7.1

#pragma once


#include "antlr4-runtime.h"
#include "SimpleCParser.h"



/**
 * This class defines an abstract visitor for a parse tree
 * produced by SimpleCParser.
 */
class  SimpleCVisitor : public antlr4::tree::AbstractParseTreeVisitor {
public:

  /**
   * Visit parse trees produced by SimpleCParser.
   */
    virtual antlrcpp::Any visitProg(SimpleCParser::ProgContext *context) = 0;

    virtual antlrcpp::Any visitHeader(SimpleCParser::HeaderContext *context) = 0;

    virtual antlrcpp::Any visitBlock(SimpleCParser::BlockContext *context) = 0;

    virtual antlrcpp::Any visitStatExpr(SimpleCParser::StatExprContext *context) = 0;

    virtual antlrcpp::Any visitStatID(SimpleCParser::StatIDContext *context) = 0;

    virtual antlrcpp::Any visitStatID_equals(SimpleCParser::StatID_equalsContext *context) = 0;

    virtual antlrcpp::Any visitStatVar(SimpleCParser::StatVarContext *context) = 0;

    virtual antlrcpp::Any visitStatIf(SimpleCParser::StatIfContext *context) = 0;

    virtual antlrcpp::Any visitStatWhile(SimpleCParser::StatWhileContext *context) = 0;

    virtual antlrcpp::Any visitStatFunc(SimpleCParser::StatFuncContext *context) = 0;

    virtual antlrcpp::Any visitStatCall(SimpleCParser::StatCallContext *context) = 0;

    virtual antlrcpp::Any visitStatRet(SimpleCParser::StatRetContext *context) = 0;

    virtual antlrcpp::Any visitVarInt(SimpleCParser::VarIntContext *context) = 0;

    virtual antlrcpp::Any visitVarBool(SimpleCParser::VarBoolContext *context) = 0;

    virtual antlrcpp::Any visitIf_stat(SimpleCParser::If_statContext *context) = 0;

    virtual antlrcpp::Any visitWhile_stat(SimpleCParser::While_statContext *context) = 0;

    virtual antlrcpp::Any visitFunction(SimpleCParser::FunctionContext *context) = 0;

    virtual antlrcpp::Any visitFunc_call(SimpleCParser::Func_callContext *context) = 0;

    virtual antlrcpp::Any visitExprMultDiv(SimpleCParser::ExprMultDivContext *context) = 0;

    virtual antlrcpp::Any visitExprFuncInt(SimpleCParser::ExprFuncIntContext *context) = 0;

    virtual antlrcpp::Any visitExprComp(SimpleCParser::ExprCompContext *context) = 0;

    virtual antlrcpp::Any visitExprAddSub(SimpleCParser::ExprAddSubContext *context) = 0;

    virtual antlrcpp::Any visitExprPara(SimpleCParser::ExprParaContext *context) = 0;

    virtual antlrcpp::Any visitExprFuncID(SimpleCParser::ExprFuncIDContext *context) = 0;

    virtual antlrcpp::Any visitExprFuncBool(SimpleCParser::ExprFuncBoolContext *context) = 0;

    virtual antlrcpp::Any visitFuncVoid(SimpleCParser::FuncVoidContext *context) = 0;

    virtual antlrcpp::Any visitFuncInt(SimpleCParser::FuncIntContext *context) = 0;

    virtual antlrcpp::Any visitFuncBool(SimpleCParser::FuncBoolContext *context) = 0;


};

