
#include "wci/intermediate/TypeSpec.h"
using namespace wci::intermediate;


// Generated from SimpleC.g4 by ANTLR 4.7.1

#pragma once


#include "antlr4-runtime.h"
#include "SimpleCVisitor.h"


/**
 * This class provides an empty implementation of SimpleCVisitor, which can be
 * extended to create a visitor which only needs to handle a subset of the available methods.
 */
class  SimpleCBaseVisitor : public SimpleCVisitor {
public:

  virtual antlrcpp::Any visitProg(SimpleCParser::ProgContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitHeader(SimpleCParser::HeaderContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitBlock(SimpleCParser::BlockContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStatExpr(SimpleCParser::StatExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStatID(SimpleCParser::StatIDContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStatID_equals(SimpleCParser::StatID_equalsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStatVar(SimpleCParser::StatVarContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStatIf(SimpleCParser::StatIfContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStatWhile(SimpleCParser::StatWhileContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStatFunc(SimpleCParser::StatFuncContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStatCall(SimpleCParser::StatCallContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStatRet(SimpleCParser::StatRetContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitVarInt(SimpleCParser::VarIntContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitVarBool(SimpleCParser::VarBoolContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitIf_stat(SimpleCParser::If_statContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitWhile_stat(SimpleCParser::While_statContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFunction(SimpleCParser::FunctionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFunc_call(SimpleCParser::Func_callContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprMultDiv(SimpleCParser::ExprMultDivContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprFuncInt(SimpleCParser::ExprFuncIntContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprComp(SimpleCParser::ExprCompContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprAddSub(SimpleCParser::ExprAddSubContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprPara(SimpleCParser::ExprParaContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprFuncID(SimpleCParser::ExprFuncIDContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprFuncBool(SimpleCParser::ExprFuncBoolContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFuncVoid(SimpleCParser::FuncVoidContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFuncInt(SimpleCParser::FuncIntContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFuncBool(SimpleCParser::FuncBoolContext *ctx) override {
    return visitChildren(ctx);
  }


};

