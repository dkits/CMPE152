/**
 * <h1>IfStatementParser</h1>
 *
 * <p>Parse a Pascal IF statement.</p>
 *
 * <p>Copyright (c) 2017 by Ronald Mak</p>
 * <p>For instructional purposes only.  No warranties.</p>
 */
#include <string>
#include <set>
#include "WhenStatementParser.h"
#include "StatementParser.h"
#include "AssignmentStatementParser.h"
#include "ExpressionParser.h"
#include "../PascalParserTD.h"
#include "../PascalToken.h"
#include "../PascalError.h"
#include "../../Token.h"
#include "../../../intermediate/ICodeNode.h"
#include "../../../intermediate/ICodeFactory.h"
#include "../../../intermediate/icodeimpl/ICodeNodeImpl.h"

namespace wci { namespace frontend { namespace pascal { namespace parsers {

using namespace std;
using namespace wci::frontend::pascal;
using namespace wci::intermediate;
using namespace wci::intermediate::icodeimpl;

bool WhenStatementParser::INITIALIZED = false;

set<PascalTokenType> WhenStatementParser::THEN_EQUALS_SET;

void WhenStatementParser::initialize()
{
    if (INITIALIZED) return;

    THEN_EQUALS_SET = StatementParser::STMT_START_SET;
    THEN_EQUALS_SET.insert(PascalTokenType::THEN_EQUALS);

    set<PascalTokenType>::iterator it;
    for (it  = StatementParser::STMT_FOLLOW_SET.begin();
         it != StatementParser::STMT_FOLLOW_SET.end();
         it++)
    {
        THEN_EQUALS_SET.insert(*it);
    }

    INITIALIZED = true;
}

WhenStatementParser::WhenStatementParser(PascalParserTD *parent)
    : StatementParser(parent)
{
    initialize();
}

ICodeNode *WhenStatementParser::parse_statement(Token *token) throw (string)
{
//FOR THE FIRST LINE********
    token = next_token(token);  // consume the WHEN

    // Create an IF node.
    ICodeNode *when_node =
            ICodeFactory::create_icode_node((ICodeNodeType) NT_WHEN);

    // Parse the expression.
    // The IF node adopts the expression subtree as its first child.
    ExpressionParser expression_parser(this);


    when_node->add_child(expression_parser.parse_statement(token));//for equals

    // Synchronize at the THEN.
    token = synchronize(THEN_EQUALS_SET);
    if (token->get_type() == (TokenType) PT_THEN_EQUALS)
    {
        token = next_token(token);  // consume the THEN
    }
    else {
        error_handler.flag(token, MISSING_THEN, this);
    }


    // Parse the THEN statement.
    // The IF node adopts the statement subtree as its second child.
    StatementParser statement_parser(this);
    when_node->add_child(statement_parser.parse_statement(token)); //for colon equals
    token = current_token();














//FOR THE SECOND LINE ************* // bottom at 3
      token = next_token(token);   //consume the semicolon

        // Create an IF node.

        // Parse the expression.
        // The IF node adopts the expression subtree as its first child.

        when_node->add_child(expression_parser.parse_statement(token));//for equals

        // Synchronize at the THEN.
        token = synchronize(THEN_EQUALS_SET);
        if (token->get_type() == (TokenType) PT_THEN_EQUALS)
        {
            token = next_token(token);  // consume the THEN
        }
        else {
            error_handler.flag(token, MISSING_THEN, this);
        }

        // Parse the THEN statement.
        // The IF node adopts the statement subtree as its second child.

        when_node->add_child(statement_parser.parse_statement(token)); //for colon equals
        token = current_token();












//FOR THE THIRD LINE*************** // top at 5
        token = next_token(token);  //consume the semicolon

            // Create an IF node.

            // Parse the expression.
            // The IF node adopts the expression subtree as its first child.

            when_node->add_child(expression_parser.parse_statement(token));//for equals

            // Synchronize at the THEN.
            token = synchronize(THEN_EQUALS_SET);
            if (token->get_type() == (TokenType) PT_THEN_EQUALS)
            {
                token = next_token(token);  // consume the THEN
            }
            else {
                error_handler.flag(token, MISSING_THEN, this);
            }

            // Parse the THEN statement.
            // The IF node adopts the statement subtree as its second child.

            when_node->add_child(statement_parser.parse_statement(token)); //for colon equals
            token = current_token();












             token = next_token(token);  //Recognizes the token is at the semicolon
             //After the semicolon
 if(token->get_type() == (TokenType) PT_IDENTIFIER) //if it has a fourth line.. execute it
      {


						 //FOR THE FOURTH LINE***************
						 when_node->add_child(expression_parser.parse_statement(token));//for equals phrase
						 token = synchronize(THEN_EQUALS_SET); //consume the =>
						 if (token->get_type() == (TokenType) PT_THEN_EQUALS)
										 {
											 token = next_token(token);
										 }
										 else {
											 error_handler.flag(token, MISSING_THEN_EQUALS, this);
										 }

						 when_node->add_child(statement_parser.parse_statement(token)); //colon equals phrase


						  }











//FOR THE OTHERWISE****************
             token = next_token(token); // consume the OTHERWISE

             if (token->get_type() == (TokenType) PT_OTHERWISE)
                                                          {

                                                            token = next_token(token);  // consume the OTHERWISE

                                                              // Parse the ELSE statement.
                                                              // The IF node adopts the statement subtree as its third child.


                                                            when_node->add_child(statement_parser.parse_statement(token));


                                                          }

             token = next_token(token); // consume the THEN_EQUALS
            /* if (token->get_type() == (TokenType) PT_THEN_EQUALS) //looks for a then equals
                                         {
                                             token = next_token(token);
                                         }
                                         else {
                                             error_handler.flag(token, MISSING_THEN_EQUALS, this);
                                         }
*/
            when_node->add_child(statement_parser.parse_statement(token)); //colon equals phrase



        /*      //  token = next_token(token); consume the semicolon

                // Create an IF node.

                // Parse the expression.
                // The IF node adopts the expression subtree as its first child.

                when_node->add_child(expression_parser.parse_statement(token));//for equals

                // Synchronize at the THEN.
                token = synchronize(THEN_EQUALS_SET);
                if (token->get_type() == (TokenType) PT_THEN_EQUALS)
                {
                    token = next_token(token);  // consume the THEN
                }
                else {
                    error_handler.flag(token, MISSING_THEN_EQUALS, this);
                }

    // Parse the THEN statement.
    // The IF node adopts the statement subtree as its second child.

    when_node->add_child(statement_parser.parse_statement(token)); //for colon equals
    token = current_token();
    */







 //************************************************************************************


//FOR SECOND PARAGRAPH (Erasing below this line until the return statement shows
  //output of first paragraph only)

token = next_token(token); // 	CONSUME SEMICOLON AT END



    return when_node;
}

}}}}  // namespace wci::frontend::pascal::parsers

/*NOTES
 *
 */
