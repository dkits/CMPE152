/**
 * <h1>CppStringToken</h1>
 *
 * <p> Cpp string tokens.</p>
 *
 * <p>Copyright (c) 2017 by Ronald Mak</p>
 * <p>For instructional purposes only.  No warranties.</p>
 */
#include "CppCharToken.h"
#include <string>
#include "../CppError.h"
namespace wci { namespace frontend { namespace cpp { namespace tokens {
using namespace std;
using namespace wci::frontend;
using namespace wci::frontend::cpp;
CppCharToken::CppCharToken(Source *source) throw (string)
        : CppToken(source)
{
    extract();
}
void CppCharToken::extract() throw (string)
{
    string value_str = "";
    char current_ch = next_char();  // consumes initial quote
    text += "'";
    // Replaces any whitespace character with blank.
    if (isspace(current_ch)) current_ch = ' ';
    // This condition handles one forward slash to be read at a time
    if (current_ch == '\\') {
        text += current_ch;
        value_str += current_ch;
        current_ch = next_char();
    }
    // This condition handles any other character as long as not slash or end of file
    if ((current_ch != '\'') && (current_ch != EOF))
    {
        text += current_ch;
        value_str  += current_ch;
        current_ch = next_char();
    }
    // This handles double slash if they are next to each other
    if (current_ch == '\'' && (peek_char() == '\''))
    {
        text += current_ch;
        value_str  += current_ch;
        current_ch = next_char();
        text += current_ch;
        type = (TokenType) PT_CHAR;
        value = (value_str);
        next_char(); // This takes the last symbol
    }
    else if (current_ch == '\'')
    {
        next_char();
        text += '\'';
        type = (TokenType) PT_CHAR;
        value = (value_str);
    }
    else
    {
        type = (TokenType) PT_ERROR;
        value = ((int) UNEXPECTED_EOF);
    }
}
}}}}  // namespace wci::frontend::Cpp::tokens
